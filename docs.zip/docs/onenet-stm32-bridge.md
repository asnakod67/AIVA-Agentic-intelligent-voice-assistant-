# OneNET × STM32 环境监测桥接

小智固件直接通过 OneNET 物联网平台（HTTP API）与 STM32 环境监测设备联动：
支持查询温湿度/火焰/震动状态、远程控制继电器/蜂鸣器/灯，并在检测到异常时主动语音告警。

## 架构

```
STM32 环境监测设备 ──(LoRa/本地组网)──> 云端数据 ──> OneNET IoT 平台 (HeClouds)
                                                          │ HTTP API (签名鉴权)
ESP32 小智 (bread-compact-wifi-lcd 128x128) ──────────────┘
  ├─ stm32.get_environment    MCP 工具：查询最新传感器数据
  ├─ stm32.control_device     MCP 工具：调用物模型服务（继电器/蜂鸣器/LED/RGB/阈值）
  └─ 后台轮询任务：每 CONFIG_ONENET_POLL_INTERVAL_MS 拉取一次，
       温度 ≥ CONFIG_ONENET_TEMP_WARN 或 flame/shock 触发 → 语音告警（60s 冷却）
```

核心实现位于 `main/boards/common/onenet_device.h`（`OnenetDeviceController`），
在 `compact_wifi_board_lcd.cc` 的 `InitializeTools()` 中注册，由 `CONFIG_ONENET_ENABLED` 控制。

## 设备与凭证

| 项目 | 值 |
| --- | --- |
| 产品 ID | `your_onenet_product_id`（menuconfig 中配置） |
| 设备名 | `stm32_env_monitor` |
| 用户 ID | `526797` |
| AccessKey | 在 menuconfig 的 `ONENET_ACCESS_KEY` 中配置（base64，勿提交到仓库） |
| 签名版本 | product-sha1-2018（HMAC-SHA1 over `et\nmethod\nres\nversion`，base64 + URL 编码） |
| 接口域名 | `https://iot-api.heclouds.com` |

鉴权令牌候选（按序尝试）：product-sha1-2018-10-31 → user-md5-2022-05-01 → device-sha1-2018-10-31。

物模型属性：`temp`(温度) / `hum`(湿度) / `flame`(火焰) / `shock`(震动) / `state`(设备状态)。
物模型服务：`relay` / `buzzer` / `led` / `rgb` / `get_status` / `ai_analyze` / `temp_threshold` / `hum_threshold`。

## 配置（menuconfig / sdkconfig）

```
CONFIG_ONENET_ENABLED=y            # 总开关（config.json 的 128x128 变体默认开启）
CONFIG_ONENET_BASE_URL             # https://iot-api.heclouds.com
CONFIG_ONENET_PRODUCT_ID           # 在 menuconfig 中配置（示例：your_onenet_product_id）
CONFIG_ONENET_DEVICE_NAME          # stm32_env_monitor
CONFIG_ONENET_USER_ID              # 526797
CONFIG_ONENET_ACCESS_KEY           # base64 AccessKey
CONFIG_ONENET_POLL_INTERVAL_MS     # 后台轮询间隔，默认 10000
CONFIG_ONENET_TEMP_WARN            # 高温告警阈值 ℃，默认 35
CONFIG_ONENET_ALERT_COOLDOWN_S     # 同类告警冷却，默认 60
```

## MCP 工具

- `stm32.get_environment`：返回最新缓存的环境数据（temp/hum/flame/shock/state/时间戳），
  首次调用前会先实时拉取一次。用于对话：*"查一下家里温度"*。
- `stm32.control_device`：`type`（relay/buzzer/led/rgb/get_status/temp_threshold/hum_threshold）+
  可选 `action`/`value`，调用物模型服务。用于对话：*"打开继电器"*、*"打开蜂鸣器"*、
  *"把温度阈值设为 30"*。

## 语音告警

| 事件 | 条件 | 音效 |
| --- | --- | --- |
| 高温 | `temp ≥ CONFIG_ONENET_TEMP_WARN` | `temp_high.ogg`：注意，室内温度过高，请注意通风降温。 |
| 火焰 | `flame == 1` | `flame_detected.ogg`：警告，检测到火焰，请注意安全。 |
| 异常 | `shock == 1` 或 `state ≥ 2` | `shock_detected.ogg`：警告，检测到异常，请注意安全。 |

告警通过 `Application::Schedule` 在主任务中播报（warning 级别），同类事件 60s 冷却。
音效位于 `main/assets/locales/zh-CN/`，由 `scripts/gen_lang.py` 生成 `lang_config.h` 常量。

## 构建与烧录

```sh
# PowerShell 环境须经 cmd 调用 IDF 导出脚本
cmd /c "call D:\esp6.0.2\esp-idf\export.bat >nul 2>&1 && python scripts\build.py bread-compact-wifi-lcd --name bread-compact-wifi-lcd-128x128"
```

**注意：不要用 merged-binary.bin 全量烧录**（镜像对未覆盖区域填充 0xFF，
会擦除 NVS 分区 0x9000，导致 WiFi 配置丢失、设备进入配网模式）。
用 build.py 输出的分段命令，或从 build 目录执行 flash_args（不覆盖 NVS）：

```sh
cmd /c "call D:\esp6.0.2\esp-idf\export.bat >nul 2>&1 && python -m esptool --chip esp32s3 -b 460800 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 16MB --flash-freq 80m 0x0 build\bootloader\bootloader.bin 0x8000 build\partition_table\partition-table.bin 0xd000 build\ota_data_initial.bin 0x20000 build\xiaozhi.bin 0x800000 build\generated_assets.bin"
```

## 故障排查

- **`invalid authorization`**：先查串口日志 `System time after sync`。
  设备时间停在 1970（无 SNTP/OTA）时令牌 et 已过期，服务器报
  `request has expired`；时间正确后报 `invalid authorization` 则是签名问题。
  本桥接会自动：① 网络就绪后通过 SNTP 同步（`CONFIG_ONENET_NTP_SERVER`）；
  ② 从服务器错误响应中的 `now=` 时间戳校准系统时钟后重试一轮。
- **无网络**：设备处于配网模式（SSID `Xiaozhi-26ED`）或 WiFi 未连接时，
  轮询静默跳过（`IsNetworkUp()` 门控），工具返回 `no network connection`。
- **签名末尾 `%00`**：mbedtls base64 编码返回长度含 NUL 终止符，
  必须分配 `n+1` 再 resize 到 `n`（已修复）。
- 串口日志中 `GET ... -> status=200` 即请求成功；`code:0` 为业务成功。

## 备注

- 依赖 `esp_http_client`（含 `crt_bundle_attach` 证书校验）；HTTP 超时 10s，
  失败自动重试下一令牌，最终回退返回最近缓存。
- 核心层不依赖本桥接；非 ESP32-S3 或关闭 `CONFIG_ONENET_ENABLED` 时自动不编译。
- 真机验证清单：① 对话查询"家里温度"应返回 STM32 实时数据；② 语音"打开继电器"
  应联动 STM32 输出；③ 升高环境温度/触发火焰后应有语音告警。
