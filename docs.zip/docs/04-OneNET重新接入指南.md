# OneNET 平台重新创建产品接入指南

> 适用于:在 OneNET Studio(物联网开放平台)从零创建产品/设备,并把本项目(ESP32 小智)
> 重新接入。覆盖平台操作步骤、物模型设计、代码侧所有需要更换的位置。

## 0. 现状(当前代码里的凭证)

| 配置项 | 当前值 | 说明 |
| --- | --- | --- |
| `CONFIG_ONENET_PRODUCT_ID` | `your_onenet_product_id` | 平台产品 ID（占位符，需替换） |
| `CONFIG_ONENET_DEVICE_NAME` | `stm32_env_monitor` | 平台设备名 |
| `CONFIG_ONENET_USER_ID` | `526797` | 平台用户 ID |
| `CONFIG_ONENET_ACCESS_KEY` | （空） | 产品 AccessKey(base64)，menuconfig 中填写 |
| `CONFIG_ONENET_BASE_URL` | `https://iot-api.heclouds.com` | 接口域名,无需改 |
| `CONFIG_ONENET_NTP_SERVER` | `ntp.aliyun.com` | 时钟同步,无需改 |

## 1. 平台操作步骤(OneNET Studio)

### 1.1 注册与登录
访问 OneNET 开放平台(open.iot.10086.cn),注册中国移动账号并登录,进入 **OneNET Studio** 控制台。

### 1.2 创建产品
1. 左侧菜单 **产品开发 → 产品列表 → 创建产品**
2. 填写:
   - **产品名称**:任意,如 `home_env_monitor`
   - **产品分类**:按实际选择(如"智能家居")或自定义
   - **接入协议**:本项目的 HTTP API 走平台 REST 接口,**与设备接入协议无关**;STM32 设备按自身能力选 MQTT 等
   - **节点类型**:设备
3. 创建成功后进入产品详情页,记录:
   - **产品 ID**(product_id)
   - **产品密钥 AccessKey**(开发设置/API 密钥处,base64 字符串)

### 1.3 获取用户 ID
控制台右上角账号信息(或"用户中心/账户管理")中查看**用户 ID**,即 `CONFIG_ONENET_USER_ID`。

### 1.4 添加设备
1. **设备管理 → 设备列表 → 添加设备**
2. 填写**设备名称**(device_name),如 `stm32_env_monitor`,鉴权信息可使用产品密钥
3. 创建后得到设备 ID(设备接入与上报用)

### 1.5 定义物模型(关键!必须与代码一致)
产品详情 → **物模型/数据流模板** → 添加:

**属性**(identifier 必须与代码查询名完全一致):

| identifier | 类型 | 含义 |
| --- | --- | --- |
| `temp` | int | 温度 ℃ |
| `hum` | int | 湿度 % |
| `flame` | int(0/1) | 火焰检测 |
| `shock` | int(0/1) | 震动检测 |
| `state` | int | 状态(0 正常/1 警告/2 危险) |

**服务**(identifier 必须与代码调用名完全一致):

| identifier | 参数 | 含义 |
| --- | --- | --- |
| `relay` | value int(0/1) | 继电器/风扇 |
| `buzzer` | value int(0/1) | 蜂鸣器 |
| `led` | value int(0/1) | 灯 |
| `rgb` | value int(0-3) | RGB 颜色 |
| `get_status` | - | 查询状态 |
| `ai_analyze` | - | 智能分析 |
| `temp_threshold` | value int | 温度阈值 |
| `hum_threshold` | value int | 湿度阈值 |

> ⚠️ **物模型 identifier 一旦与代码不一致,查询返回空、控制报错**。
> 改平台侧时同步改代码(见 §3)。

### 1.6 联调验证(设备上线前)
- 用平台 **设备调试/模拟设备** 上报属性 `temp/hum/flame/shock/state`
- 用平台 API 调试工具调用 `query-device-property` 确认返回格式:
  `data.properties[]` 为 `{ "identifier": "...", "value": ... }` 数组

## 2. 签名鉴权机制(理解即可)

```
Authorization: version=2018-10-31&res=products/<PRODUCT_ID>&et=<过期时间戳>&method=sha1&sign=<HMAC-SHA1 签名>
sign = Base64(HMAC-SHA1( Base64Decode(ACCESS_KEY), "et\nmethod\nres\nversion" ))  (URL 编码)
```

代码按序尝试 3 种令牌(`main/boards/common/onenet_device.h` `BuildCandidateTokens`):
1. `sha1` + `products/<product_id>`(版本 2018-10-31)
2. `md5` + `userid/<user_id>`(版本 2022-05-01)
3. `sha1` + `products/<product_id>/devices/<device_name>`(版本 2018-10-31)

任一种鉴权通过即可;配置了产品 AccessKey 时第 1 种即可生效。

## 3. 代码侧需要更换的位置(全部列出)

| # | 文件 | 位置 | 改什么 |
| --- | --- | --- | --- |
| 1 | `main/Kconfig.projbuild` | `ONENET_PRODUCT_ID` 默认值(L1091) | 新产品 ID |
| 2 | `main/Kconfig.projbuild` | `ONENET_DEVICE_NAME` 默认值(L1096) | 新设备名 |
| 3 | `main/Kconfig.projbuild` | `ONENET_USER_ID` 默认值(L1100) | 新用户 ID |
| 4 | `main/Kconfig.projbuild` | `ONENET_ACCESS_KEY` 默认值(L1105) | 新 AccessKey(base64) |
| 5 | `sdkconfig`(已生成) | 对应 `CONFIG_ONENET_*` 行 | 与 1-4 同步(由 menuconfig 或重新构建生成) |
| 6 | `docs/onenet-stm32-bridge.md` | "设备与凭证"表 | 同步新值 |

**推荐改法**:不改 Kconfig 默认值,直接

```sh
idf.py menuconfig   # 或修改 sdkconfig
```
修改 4 个 `CONFIG_ONENET_*` 值后重新构建。

**不需要改**:
- `CONFIG_ONENET_BASE_URL`(域名固定)
- `CONFIG_ONENET_NTP_SERVER`
- 任何物模型字段名对应的代码逻辑(前提:平台物模型按 §1.5 建)

## 4. 物模型变更联动(如果你改了 identifier)

查询属性名(代码侧)位于 `main/boards/common/onenet_device.h`:
- `GetPropertyValue(data, "temp"/"hum"/"flame"/"shock"/"state")` — 查询环境时解析的 5 个属性
- `IsValidControl()` 中 `relay/buzzer/led/rgb/get_status/ai_analyze/temp_threshold/hum_threshold` — 控制白名单

服务调用通过 POST 物模型服务 API,参数 `{"identifier": "...", "value": ...}`。
若平台侧改了名字,上述两处字符串需同步修改。

## 5. STM32 侧(设备上报)

STM32 端按新产品的接入参数(产品 ID、设备名、鉴权信息、MQTT 端点)重新配置后上线,
上报物模型属性 `temp/hum/flame/shock/state`。ESP32 轮询(默认 10s)即可读到新数据。

## 6. 重新构建与烧录

```sh
cmd /c "call D:\esp6.0.2\esp-idf\export.bat >nul 2>&1 && python scripts\build.py bread-compact-wifi-lcd --name bread-compact-wifi-lcd-128x128"
```

分段烧录(勿用 merged 全量):

```sh
cmd /c "call D:\esp6.0.2\esp-idf\export.bat >nul 2>&1 && python -m esptool --chip esp32s3 -p COM5 -b 460800 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 16MB --flash-freq 80m 0x0 build\bootloader\bootloader.bin 0x8000 build\partition_table\partition-table.bin 0xd000 build\ota_data_initial.bin 0x20000 build\xiaozhi.bin 0x800000 build\generated_assets.bin"
```

## 7. 验收清单

- 串口日志:`GET ...query-device-property... -> status=200`,`code:0` 业务成功
- 说"查询环境"→ 播报新产品的温度/湿度
- 说"打开设备/关闭设备"→ relay 动作
- 若报 `invalid authorization`/`request has expired`:核对 4 个凭证值 + 系统时间
  (日志 `System time after sync` 应为当前时间,SNTP 会自动同步)
