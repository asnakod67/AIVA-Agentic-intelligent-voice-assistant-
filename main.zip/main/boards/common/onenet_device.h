#ifndef __ONENET_DEVICE_H__
#define __ONENET_DEVICE_H__

#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include <time.h>

#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_log.h>
#include <esp_netif.h>
#include <esp_netif_sntp.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <mbedtls/base64.h>
#include <mbedtls/md.h>
#include <cJSON.h>

#include "application.h"
#include "mcp_server.h"

#define ONENET_TAG "OnenetDevice"

// Bridge between the XiaoZhi voice assistant and the STM32 environment
// monitor. Uses the OneNET IoT platform HTTP API (same endpoints and
// product-sha1-2018 signature as the WeChat cloud function onenetProxy).
//
//  - stm32.get_environment: returns the latest sensor data (cache, live
//    refreshed by a background poll task).
//  - stm32.control_device:  invokes an OneNET thing-model service, which
//    OneNET forwards to the STM32 (relay/buzzer/led/rgb/...).
//  - A background task polls the device properties and raises a voice
//    alert on temperature/flame/shock thresholds.
class OnenetDeviceController {
private:
    struct EnvironmentData {
        bool valid = false;
        int temp = -1;
        int hum = -1;
        int flame = -1;
        int shock = -1;
        int state = -1;
        uint64_t fetch_us = 0;
        std::string raw;
    };

    std::mutex data_mutex_;
    EnvironmentData data_;
    bool last_temp_high_ = false;
    bool last_flame_ = false;
    bool last_shock_ = false;
    uint64_t last_alert_us_ = 0;

    static std::string UrlEncode(const std::string& value) {
        static const char* hex = "0123456789ABCDEF";
        std::string out;
        for (unsigned char c : value) {
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
                c == '-' || c == '_' || c == '.' || c == '~') {
                out += static_cast<char>(c);
            } else {
                out += '%';
                out += hex[(c >> 4) & 0xF];
                out += hex[c & 0xF];
            }
        }
        return out;
    }

    static std::string Base64Encode(const unsigned char* data, size_t len) {
        // mbedtls requires dst >= n+1 (it NUL-terminates) and, when called
        // with dst==NULL, reports n+1. Allocate n+1 and resize to n.
        size_t n = (len + 2) / 3 * 4;
        std::string result(n + 1, 0);
        size_t dlen = 0;
        if (mbedtls_base64_encode(reinterpret_cast<unsigned char*>(result.data()), result.size(),
                                  &dlen, data, len) == 0) {
            result.resize(dlen);
        }
        return result;
    }

    static std::string Base64Decode(const char* data) {
        size_t dlen = strlen(data);
        size_t olen = 0;
        if (mbedtls_base64_decode(nullptr, 0, &olen, reinterpret_cast<const unsigned char*>(data), dlen) != MBEDTLS_ERR_BASE64_INVALID_CHARACTER) {
            std::string result(olen, 0);
            if (mbedtls_base64_decode(reinterpret_cast<unsigned char*>(result.data()), result.size(), &olen,
                                      reinterpret_cast<const unsigned char*>(data), dlen) == 0) {
                return result;
            }
        }
        return "";
    }

    // OneNET product AccessKeys are base64 strings (the cloud function also
    // accepts hex strings; the current key is base64).
    static std::string DecodeAccessKey() {
        return Base64Decode(CONFIG_ONENET_ACCESS_KEY);
    }

    static std::string HmacBase64(const std::string& key, const std::string& message, mbedtls_md_type_t md_type) {
        const mbedtls_md_info_t* md_info = mbedtls_md_info_from_type(md_type);
        if (md_info == nullptr) {
            return "";
        }
        unsigned char output[32] = {};
        mbedtls_md_hmac(md_info, reinterpret_cast<const unsigned char*>(key.data()), key.size(),
                        reinterpret_cast<const unsigned char*>(message.data()), message.size(), output);
        size_t olen = 0;
        switch (md_type) {
            case MBEDTLS_MD_MD5:
                olen = 16;
                break;
            case MBEDTLS_MD_SHA1:
                olen = 20;
                break;
            default:
                return "";
        }
        return Base64Encode(output, olen);
    }

    // Same token format as onenetProxy: version=..&res=..&et=..&method=..&sign=..
    static std::string BuildToken(const std::string& method, const std::string& res, const std::string& version) {
        uint32_t et = static_cast<uint32_t>(time(nullptr)) + 86400u * 365u * 10u;
        std::string sign_str = std::to_string(et) + "\n" + method + "\n" + res + "\n" + version;
        mbedtls_md_type_t md_type = (method == "md5") ? MBEDTLS_MD_MD5 : MBEDTLS_MD_SHA1;
        std::string key = DecodeAccessKey();
        if (key.empty()) {
            return "";
        }
        std::string sign = HmacBase64(key, sign_str, md_type);
        if (sign.empty()) {
            return "";
        }
        return "version=" + version + "&res=" + UrlEncode(res) + "&et=" + std::to_string(et) +
               "&method=" + method + "&sign=" + UrlEncode(sign);
    }

    // Candidates tried in order; OneNET accepts product/user/device scopes.
    std::vector<std::string> BuildCandidateTokens() {
        std::string product_res = "products/" + std::string(CONFIG_ONENET_PRODUCT_ID);
        std::string device_res = product_res + "/devices/" + std::string(CONFIG_ONENET_DEVICE_NAME);
        std::string user_res = "userid/" + std::string(CONFIG_ONENET_USER_ID);
        std::vector<std::string> tokens;
        tokens.push_back(BuildToken("sha1", product_res, "2018-10-31"));
        tokens.push_back(BuildToken("md5", user_res, "2022-05-01"));
        tokens.push_back(BuildToken("sha1", device_res, "2018-10-31"));
        return tokens;
    }

    static bool IsAuthFailure(const std::string& body) {
        return body.find("invalid authorization") != std::string::npos ||
               body.find("authentication failed") != std::string::npos ||
               body.find("authorization") != std::string::npos ||
               body.find("鉴权") != std::string::npos;
    }

    // Only run HTTP requests when the station has a working IP stack.
    static bool IsNetworkUp() {
        esp_netif_t* sta = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
        return sta != nullptr && esp_netif_is_netif_up(sta);
    }

    // OneNET tokens embed an expiry timestamp (et) derived from the system
    // clock. Without SNTP the clock stays at 1970 and every token is already
    // expired ("invalid authorization"). Init SNTP once and let lwIP keep
    // retrying in the background until the network is up; re-init on each
    // call only when the stack was not ready yet.
    static void EnsureTimeSynced() {
        static bool sntp_started = false;
        const time_t kMinValid = 1704067200;  // 2024-01-01
        if (time(nullptr) >= kMinValid) {
            return;
        }
        if (!IsNetworkUp()) {
            return;
        }
        if (!sntp_started) {
            ESP_LOGW(ONENET_TAG, "System time not set, syncing via SNTP (%s)",
                     CONFIG_ONENET_NTP_SERVER);
            esp_sntp_config_t config = ESP_NETIF_SNTP_DEFAULT_CONFIG(CONFIG_ONENET_NTP_SERVER);
            config.wait_for_sync = true;
            sntp_started = (esp_netif_sntp_init(&config) == ESP_OK);
            if (!sntp_started) {
                return;
            }
        }
        esp_netif_sntp_sync_wait(pdMS_TO_TICKS(3000));
        ESP_LOGW(ONENET_TAG, "System time after sync: %lld",
                 static_cast<long long>(time(nullptr)));
    }

    // OneNET rejects expired tokens but includes the server's current epoch
    // in the error message ("...now=1785575630."). Adopt it to heal the clock
    // even if SNTP is unreachable.
    static bool TrySetTimeFromBody(const std::string& body) {
        size_t pos = body.find("now=");
        if (pos == std::string::npos) {
            return false;
        }
        long long now = strtoll(body.c_str() + pos + 4, nullptr, 10);
        if (now < 1704067200) {
            return false;
        }
        timeval tv = {};
        tv.tv_sec = static_cast<time_t>(now);
        settimeofday(&tv, nullptr);
        ESP_LOGW(ONENET_TAG, "Adopted server time from auth error: %lld",
                 static_cast<long long>(now));
        return true;
    }

    static std::string HttpRequest(const std::string& method, const std::string& url, const std::string& token,
                                   const std::string& payload, int* status_out) {
        esp_http_client_config_t cfg = {};
        cfg.url = url.c_str();
        cfg.method = (method == "POST") ? HTTP_METHOD_POST : HTTP_METHOD_GET;
        cfg.timeout_ms = 10000;
        cfg.skip_cert_common_name_check = true;
        cfg.crt_bundle_attach = esp_crt_bundle_attach;
        esp_http_client_handle_t client = esp_http_client_init(&cfg);
        if (client == nullptr) {
            return "";
        }
        esp_http_client_set_header(client, "Authorization", token.c_str());
        if (method == "POST") {
            esp_http_client_set_header(client, "Content-Type", "application/json");
        }
        std::string response;
        esp_err_t err = esp_http_client_open(client, payload.size());
        if (err == ESP_OK) {
            if (!payload.empty()) {
                esp_http_client_write(client, payload.data(), payload.size());
            }
            esp_http_client_fetch_headers(client);
            if (status_out != nullptr) {
                *status_out = esp_http_client_get_status_code(client);
            }
            char buf[256];
            int len;
            while ((len = esp_http_client_read(client, buf, sizeof(buf) - 1)) > 0) {
                buf[len] = 0;
                response.append(buf, len);
            }
        } else if (status_out != nullptr) {
            *status_out = 0;
        }
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        ESP_LOGI(ONENET_TAG, "%s %s -> status=%d", method.c_str(), url.c_str(),
                 status_out ? *status_out : -1);
        return response;
    }

    // The query response "data" is an array of property objects, each with
    // {"identifier": "...", "value": ...}.
    static int GetPropertyValue(const cJSON* data, const char* name) {
        const cJSON* props = cJSON_GetObjectItem(data, "properties");
        const cJSON* container = props != nullptr ? props : data;
        if (cJSON_IsArray(container)) {
            const cJSON* item = nullptr;
            cJSON_ArrayForEach(item, container) {
                const cJSON* identifier = cJSON_GetObjectItem(item, "identifier");
                const cJSON* value = cJSON_GetObjectItem(item, "value");
                if (identifier != nullptr && cJSON_IsString(identifier) &&
                    strcmp(identifier->valuestring, name) == 0 && value != nullptr) {
                    if (cJSON_IsNumber(value)) {
                        return value->valueint;
                    }
                    if (cJSON_IsString(value)) {
                        return atoi(value->valuestring);
                    }
                }
            }
            return -1;
        }
        const cJSON* item = cJSON_GetObjectItem(container, name);
        if (item == nullptr) {
            return -1;
        }
        const cJSON* value = cJSON_GetObjectItem(item, "value");
        if (value != nullptr && cJSON_IsNumber(value)) {
            return value->valueint;
        }
        if (cJSON_IsNumber(item)) {
            return item->valueint;
        }
        return -1;
    }

    // Live query with token fallback, mirroring onenetProxy behavior. If the
    // clock was stale, the server time adopted from the auth error lets the
    // second pass rebuild tokens with a valid expiry.
    std::string QueryProperties() {
        EnsureTimeSynced();
        if (!IsNetworkUp()) {
            return "";
        }
        std::string url = std::string(CONFIG_ONENET_BASE_URL) + "/thingmodel/query-device-property?product_id=" +
                          CONFIG_ONENET_PRODUCT_ID + "&device_name=" + CONFIG_ONENET_DEVICE_NAME;
        std::string last_body;
        for (int pass = 0; pass < 2; ++pass) {
            for (const auto& token : BuildCandidateTokens()) {
                if (token.empty()) {
                    continue;
                }
                int status = 0;
                last_body = HttpRequest("GET", url, token, "", &status);
                if (!last_body.empty() && status >= 200 && status < 300 && IsQuerySuccess(last_body)) {
                    return last_body;
                }
                if (IsAuthFailure(last_body)) {
                    TrySetTimeFromBody(last_body);
                    continue;
                }
                break;
            }
            if (time(nullptr) < 1704067200) {
                break;
            }
        }
        return last_body;
    }

    static bool IsQuerySuccess(const std::string& body) {
        cJSON* root = cJSON_Parse(body.c_str());
        if (root == nullptr) {
            return false;
        }
        cJSON* code = cJSON_GetObjectItem(root, "code");
        bool ok = code != nullptr && cJSON_IsNumber(code) && code->valueint == 0;
        cJSON_Delete(root);
        return ok;
    }

    void UpdateCache(const std::string& body) {
        cJSON* root = cJSON_Parse(body.c_str());
        if (root == nullptr) {
            return;
        }
        const cJSON* data_item = cJSON_GetObjectItem(root, "data");
        if (data_item == nullptr) {
            cJSON_Delete(root);
            return;
        }
        EnvironmentData new_data;
        new_data.temp = GetPropertyValue(data_item, "temp");
        new_data.hum = GetPropertyValue(data_item, "hum");
        new_data.flame = GetPropertyValue(data_item, "flame");
        new_data.shock = GetPropertyValue(data_item, "shock");
        new_data.state = GetPropertyValue(data_item, "state");
        if (new_data.temp < 0 && new_data.hum < 0 && new_data.flame < 0 && new_data.shock < 0 && new_data.state < 0) {
            cJSON_Delete(root);
            return;
        }
        new_data.valid = true;
        new_data.fetch_us = esp_timer_get_time();
        new_data.raw = body;
        {
            std::lock_guard<std::mutex> lock(data_mutex_);
            data_ = new_data;
        }
        cJSON_Delete(root);
    }

    void EvaluateAlerts() {
        EnvironmentData snapshot;
        {
            std::lock_guard<std::mutex> lock(data_mutex_);
            snapshot = data_;
        }
        if (!snapshot.valid) {
            return;
        }
        bool temp_high = snapshot.temp >= CONFIG_ONENET_TEMP_WARN;
        bool fire = snapshot.flame == 1;
        bool abnormal = snapshot.shock == 1 || snapshot.state >= 2;
        bool trigger = (temp_high && !last_temp_high_) || (fire && !last_flame_) || (abnormal && !last_shock_);
        last_temp_high_ = temp_high;
        last_flame_ = fire;
        last_shock_ = abnormal;
        if (!trigger) {
            return;
        }
        uint64_t now_us = esp_timer_get_time();
        if (now_us - last_alert_us_ < static_cast<uint64_t>(CONFIG_ONENET_ALERT_COOLDOWN_S) * 1000000ull) {
            return;
        }
        last_alert_us_ = now_us;

        std::string message;
        std::string_view sound;
        if (fire) {
            message = "检测到火焰";
            sound = Lang::Sounds::OGG_FLAME_DETECTED;
        } else if (abnormal) {
            message = "检测到异常，请注意";
            sound = Lang::Sounds::OGG_SHOCK_DETECTED;
        } else {
            message = "室内温度过高";
            sound = Lang::Sounds::OGG_TEMP_HIGH;
        }
        ESP_LOGW(ONENET_TAG, "Environment alert: %s", message.c_str());
        Application::GetInstance().Schedule([message, sound]() {
            Application::GetInstance().Alert(Lang::Strings::WARNING, message.c_str(), "warning", sound);
        });
    }

    std::string GetEnvironmentJson() {
        bool valid = false;
        uint64_t fetch_us = 0;
        EnvironmentData snapshot;
        {
            std::lock_guard<std::mutex> lock(data_mutex_);
            snapshot = data_;
            valid = data_.valid;
            fetch_us = data_.fetch_us;
        }
        uint64_t age_us = valid ? esp_timer_get_time() - fetch_us : 0;
        if (!valid || age_us > 60ull * 1000000ull) {
            std::string body = QueryProperties();
            if (!body.empty() && IsQuerySuccess(body)) {
                UpdateCache(body);
                {
                    std::lock_guard<std::mutex> lock(data_mutex_);
                    snapshot = data_;
                }
            }
        }

        cJSON* json = cJSON_CreateObject();
        cJSON_AddBoolToObject(json, "valid", snapshot.valid);
        if (snapshot.valid) {
            cJSON_AddNumberToObject(json, "temperature_celsius", snapshot.temp);
            cJSON_AddNumberToObject(json, "humidity_percent", snapshot.hum);
            cJSON_AddNumberToObject(json, "flame", snapshot.flame);
            cJSON_AddNumberToObject(json, "shock", snapshot.shock);
            cJSON_AddNumberToObject(json, "state", snapshot.state);
        }
        char* json_str = cJSON_PrintUnformatted(json);
        std::string result(json_str);
        cJSON_free(json_str);
        cJSON_Delete(json);
        return result;
    }

    static bool IsValidControl(const std::string& identifier, int value) {
        if (identifier == "relay" || identifier == "buzzer" || identifier == "led") {
            return value == 0 || value == 1;
        }
        if (identifier == "rgb") {
            return value >= 0 && value <= 3;
        }
        if (identifier == "get_status" || identifier == "ai_analyze") {
            return true;
        }
        if (identifier == "temp_threshold" || identifier == "hum_threshold") {
            return value >= -50 && value <= 200;
        }
        return false;
    }

    std::string ControlDevice(const std::string& identifier, int value) {
        EnsureTimeSynced();
        if (!IsNetworkUp()) {
            return R"({"success":false,"error":"no network connection"})";
        }
        if (!IsValidControl(identifier, value)) {
            cJSON* err = cJSON_CreateObject();
            cJSON_AddBoolToObject(err, "success", false);
            cJSON_AddStringToObject(err, "error", "unsupported service or value");
            char* json_str = cJSON_PrintUnformatted(err);
            std::string result(json_str);
            cJSON_free(json_str);
            cJSON_Delete(err);
            return result;
        }
        if (identifier == "get_status" || identifier == "ai_analyze") {
            value = 1;
        }

        cJSON* body = cJSON_CreateObject();
        cJSON_AddStringToObject(body, "product_id", CONFIG_ONENET_PRODUCT_ID);
        cJSON_AddStringToObject(body, "device_name", CONFIG_ONENET_DEVICE_NAME);
        cJSON_AddStringToObject(body, "identifier", identifier.c_str());
        cJSON* params = cJSON_CreateObject();
        cJSON_AddNumberToObject(params, "value", value);
        cJSON_AddItemToObject(body, "params", params);
        char* body_str = cJSON_PrintUnformatted(body);

        std::string url = std::string(CONFIG_ONENET_BASE_URL) + "/thingmodel/call-service";
        std::string last_body;
        for (int pass = 0; pass < 2; ++pass) {
            for (const auto& token : BuildCandidateTokens()) {
                if (token.empty()) {
                    continue;
                }
                int status = 0;
                last_body = HttpRequest("POST", url, token, body_str, &status);
                if (!last_body.empty() && status >= 200 && status < 300 && IsServiceSuccess(last_body)) {
                    cJSON_free(body_str);
                    cJSON_Delete(body);
                    return last_body;
                }
                if (IsAuthFailure(last_body)) {
                    TrySetTimeFromBody(last_body);
                    continue;
                }
                break;
            }
            if (time(nullptr) < 1704067200) {
                break;
            }
        }
        cJSON_free(body_str);
        cJSON_Delete(body);

        cJSON* err = cJSON_CreateObject();
        cJSON_AddBoolToObject(err, "success", false);
        cJSON_AddStringToObject(err, "error", "OneNET service call failed");
        cJSON_AddStringToObject(err, "response", last_body.c_str());
        char* json_str = cJSON_PrintUnformatted(err);
        std::string result(json_str);
        cJSON_free(json_str);
        cJSON_Delete(err);
        return result;
    }

    static bool IsServiceSuccess(const std::string& body) {
        cJSON* root = cJSON_Parse(body.c_str());
        if (root == nullptr) {
            return false;
        }
        cJSON* code = cJSON_GetObjectItem(root, "code");
        cJSON* success = cJSON_GetObjectItem(root, "success");
        bool ok = (code != nullptr && cJSON_IsNumber(code) && code->valueint == 0) ||
                  (success != nullptr && cJSON_IsTrue(success));
        cJSON_Delete(root);
        return ok;
    }

    static void PollTask(void* arg) {
        auto* self = static_cast<OnenetDeviceController*>(arg);
        TickType_t last_wake = xTaskGetTickCount();
        while (true) {
            vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(CONFIG_ONENET_POLL_INTERVAL_MS));
            std::string body = self->QueryProperties();
            if (body.empty() || !IsQuerySuccess(body)) {
                continue;
            }
            self->UpdateCache(body);
            self->EvaluateAlerts();
        }
    }

public:
    OnenetDeviceController() {
        auto& mcp_server = McpServer::GetInstance();
        mcp_server.AddTool("stm32.get_environment",
            "Get the latest environment data from the STM32 home monitor: "
            "temperature_celsius, humidity_percent, flame (0/1), shock (0/1) and state "
            "(0 normal, 1 warning, 2 danger). Use this tool when the user asks about "
            "the temperature, humidity or home safety.",
            PropertyList(),
            [this](const PropertyList& properties) -> ReturnValue {
                return GetEnvironmentJson();
            });

        mcp_server.AddTool("stm32.control_device",
            "Control a device connected to the STM32 home monitor. "
            "identifier is one of: relay (cooling fan, value 0/1), buzzer (0/1), "
            "led (0/1), rgb (0 red, 1 green, 2 blue, 3 off), get_status, ai_analyze, "
            "temp_threshold, hum_threshold. Use this tool when the user asks to turn "
            "the fan/buzzer/light on or off, or to change a threshold.",
            PropertyList({
                Property("identifier", kPropertyTypeString),
                Property("value", kPropertyTypeInteger),
            }),
            [this](const PropertyList& properties) -> ReturnValue {
                std::string identifier = properties["identifier"].value<std::string>();
                int value = properties["value"].value<int>();
                ESP_LOGW(ONENET_TAG, "control_device: %s=%d", identifier.c_str(), value);
                return ControlDevice(identifier, value);
            });

        xTaskCreate(&OnenetDeviceController::PollTask, "onenet_poll", 4096, this, 2, nullptr);
    }

    // Public wrappers for the offline command word handlers (board layer).
    std::string QueryEnvironment() { return GetEnvironmentJson(); }
    std::string Control(const std::string& identifier, int value) { return ControlDevice(identifier, value); }
};

#endif // __ONENET_DEVICE_H__
