#include "application.h"
#include "assets.h"
#include "assets/lang_config.h"
#include "audio_codec.h"
#include "board.h"
#include "display.h"
#include "mcp_server.h"
#include "mqtt_protocol.h"
#include "settings.h"
#include "system_info.h"
#include "text_glyph_payload.h"
#include "tts_player.h"
#include "websocket_protocol.h"

#include <driver/gpio.h>
#include <esp_log.h>
#include <arpa/inet.h>
#include <cJSON.h>
#include <cstring>

#define TAG "Application"


/*
 * ================================================================
 * HYBRID OFFLINE COMMAND STATE
 * ================================================================
 *
 * false:
 *     Offline command words are ignored.
 *
 * true:
 *     A wake word was detected but the online server could not
 *     be reached. The next offline command is allowed to execute.
 *
 * This is intentionally kept in application.cc so no change to
 * application.h is required.
 */
#if CONFIG_USE_OFFLINE_COMMANDS
static bool g_offline_command_armed = false;
#endif


Application::Application() {
    event_group_ = xEventGroupCreate();

#if CONFIG_USE_DEVICE_AEC && CONFIG_USE_SERVER_AEC
#error "CONFIG_USE_DEVICE_AEC and CONFIG_USE_SERVER_AEC cannot be enabled at the same time"
#elif CONFIG_USE_DEVICE_AEC
    aec_mode_ = kAecOnDeviceSide;
#elif CONFIG_USE_SERVER_AEC
    aec_mode_ = kAecOnServerSide;
#else
    aec_mode_ = kAecOff;
#endif

    esp_timer_create_args_t clock_timer_args = {
        .callback =
            [](void* arg) {
                Application* app =
                    static_cast<Application*>(arg);

                xEventGroupSetBits(
                    app->event_group_,
                    MAIN_EVENT_CLOCK_TICK
                );
            },

        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "clock_timer",
        .skip_unhandled_events = true
    };

    esp_timer_create(
        &clock_timer_args,
        &clock_timer_handle_
    );
}


Application::~Application() {

    if (clock_timer_handle_ != nullptr) {
        esp_timer_stop(clock_timer_handle_);
        esp_timer_delete(clock_timer_handle_);
    }

    vEventGroupDelete(event_group_);
}


bool Application::SetDeviceState(
    DeviceState state) {

    return state_machine_.TransitionTo(state);
}


void Application::Initialize() {

    auto& board =
        Board::GetInstance();

    SetDeviceState(
        kDeviceStateStarting
    );


    // ============================================================
    // DISPLAY
    // ============================================================

    auto display =
        board.GetDisplay();

    display->SetupUI();

    display->SetChatMessage(
        "system",
        SystemInfo::GetUserAgent().c_str()
    );


    // ============================================================
    // AUDIO SERVICE
    // ============================================================

    auto codec =
        board.GetAudioCodec();

    audio_service_.Initialize(codec);
    audio_service_.Start();


    AudioServiceCallbacks callbacks;


    callbacks.on_send_queue_available =
        [this]() {

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_SEND_AUDIO
            );
        };


    callbacks.on_wake_word_detected =
        [this](const std::string& wake_word) {

            (void)wake_word;

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_WAKE_WORD_DETECTED
            );
        };


#if CONFIG_USE_OFFLINE_COMMANDS

    callbacks.on_command_detected =
        [this](
            const std::string& text,
            const std::string& action) {

            Schedule(
                [this, text, action]() {
                    HandleCommandDetected(
                        text,
                        action
                    );
                }
            );
        };

#else

    callbacks.on_command_detected =
        [this](
            const std::string& text,
            const std::string& action) {

            (void)text;
            (void)action;
        };

#endif


    callbacks.on_vad_change =
        [this](bool speaking) {

            (void)speaking;

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_VAD_CHANGE
            );
        };


    callbacks.on_playback_drained =
        [this]() {

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_PLAYBACK_DRAINED
            );
        };


    audio_service_.SetCallbacks(
        callbacks
    );


    // ============================================================
    // STATE CHANGE LISTENER
    // ============================================================

    state_machine_.AddStateChangeListener(
        [this](
            DeviceState old_state,
            DeviceState new_state) {

            (void)old_state;
            (void)new_state;

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_STATE_CHANGED
            );
        }
    );


    // ============================================================
    // CLOCK
    // ============================================================

    esp_timer_start_periodic(
        clock_timer_handle_,
        1000000
    );


    // ============================================================
    // MCP TOOLS
    // ============================================================

    auto& mcp_server =
        McpServer::GetInstance();

    mcp_server.AddCommonTools();
    mcp_server.AddUserOnlyTools();


    // ============================================================
    // NETWORK EVENTS
    // ============================================================

    board.SetNetworkEventCallback(
        [this](
            NetworkEvent event,
            const std::string& data) {

            auto display =
                Board::GetInstance().GetDisplay();


            switch (event) {

                case NetworkEvent::Scanning:

                    display->ShowNotification(
                        Lang::Strings::SCANNING_WIFI,
                        30000
                    );

                    xEventGroupSetBits(
                        event_group_,
                        MAIN_EVENT_NETWORK_DISCONNECTED
                    );

                    break;


                case NetworkEvent::Connecting: {

                    if (data.empty()) {

                        display->SetStatus(
                            Lang::Strings::REGISTERING_NETWORK
                        );

                    } else {

                        std::string msg =
                            Lang::Strings::CONNECT_TO;

                        msg += data;
                        msg += "...";

                        display->ShowNotification(
                            msg.c_str(),
                            30000
                        );
                    }

                    break;
                }


                case NetworkEvent::Connected: {

                    std::string msg =
                        Lang::Strings::CONNECTED_TO;

                    msg += data;

                    display->ShowNotification(
                        msg.c_str(),
                        30000
                    );

                    xEventGroupSetBits(
                        event_group_,
                        MAIN_EVENT_NETWORK_CONNECTED
                    );

                    break;
                }


                case NetworkEvent::Disconnected:

                    xEventGroupSetBits(
                        event_group_,
                        MAIN_EVENT_NETWORK_DISCONNECTED
                    );

                    break;


                case NetworkEvent::WifiConfigModeEnter:

                    break;


                case NetworkEvent::WifiConfigModeExit:

                    break;


                // Cellular modem events

                case NetworkEvent::ModemDetecting:

                    display->SetStatus(
                        Lang::Strings::DETECTING_MODULE
                    );

                    break;


                case NetworkEvent::ModemErrorNoSim:

                    Alert(
                        Lang::Strings::ERROR,
                        Lang::Strings::PIN_ERROR,
                        "warning",
                        Lang::Sounds::OGG_ERR_PIN
                    );

                    break;


                case NetworkEvent::ModemErrorRegDenied:

                    Alert(
                        Lang::Strings::ERROR,
                        Lang::Strings::REG_ERROR,
                        "warning",
                        Lang::Sounds::OGG_ERR_REG
                    );

                    break;


                case NetworkEvent::ModemErrorInitFailed:

                    Alert(
                        Lang::Strings::ERROR,
                        Lang::Strings::MODEM_INIT_ERROR,
                        "warning",
                        Lang::Sounds::OGG_EXCLAMATION
                    );

                    break;


                case NetworkEvent::ModemErrorTimeout:

                    display->SetStatus(
                        Lang::Strings::REGISTERING_NETWORK
                    );

                    break;
            }
        }
    );


    // ============================================================
    // START NETWORK
    // ============================================================

    board.StartNetwork();

    display->UpdateStatusBar(true);
}


void Application::Run() {

    /*
     * Main application task priority.
     */
    vTaskPrioritySet(
        nullptr,
        10
    );


    const EventBits_t ALL_EVENTS =
        MAIN_EVENT_SCHEDULE |
        MAIN_EVENT_SEND_AUDIO |
        MAIN_EVENT_WAKE_WORD_DETECTED |
        MAIN_EVENT_VAD_CHANGE |
        MAIN_EVENT_CLOCK_TICK |
        MAIN_EVENT_ERROR |
        MAIN_EVENT_NETWORK_CONNECTED |
        MAIN_EVENT_NETWORK_DISCONNECTED |
        MAIN_EVENT_TOGGLE_CHAT |
        MAIN_EVENT_START_LISTENING |
        MAIN_EVENT_STOP_LISTENING |
        MAIN_EVENT_ACTIVATION_DONE |
        MAIN_EVENT_STATE_CHANGED |
        MAIN_EVENT_PLAYBACK_DRAINED;


    while (true) {

        auto bits =
            xEventGroupWaitBits(
                event_group_,
                ALL_EVENTS,
                pdTRUE,
                pdFALSE,
                portMAX_DELAY
            );


        // ========================================================
        // NETWORK / PROTOCOL ERROR
        // ========================================================

        if (bits & MAIN_EVENT_ERROR) {

            ESP_LOGW(
                TAG,
                "Protocol/network error: %s",
                last_error_message_.c_str()
            );

            SetDeviceState(
                kDeviceStateIdle
            );

            Alert(
                Lang::Strings::ERROR,
                last_error_message_.c_str(),
                "cancel",
                Lang::Sounds::OGG_EXCLAMATION
            );
        }


        // ========================================================
        // NETWORK CONNECTED
        // ========================================================

        if (bits & MAIN_EVENT_NETWORK_CONNECTED) {

#if CONFIG_USE_OFFLINE_COMMANDS

            /*
             * A network connection has returned.
             *
             * Exit the temporary offline-command session.
             */
            if (g_offline_command_armed) {

                ESP_LOGI(
                    TAG,
                    "Network restored - clearing offline command mode"
                );

                g_offline_command_armed = false;
            }

#endif

            HandleNetworkConnectedEvent();
        }


        // ========================================================
        // NETWORK DISCONNECTED
        // ========================================================

        if (bits & MAIN_EVENT_NETWORK_DISCONNECTED) {

            HandleNetworkDisconnectedEvent();
        }


        // ========================================================
        // ACTIVATION COMPLETE
        // ========================================================

        if (bits & MAIN_EVENT_ACTIVATION_DONE) {

            HandleActivationDoneEvent();
        }


        // ========================================================
        // STATE CHANGED
        // ========================================================

        if (bits & MAIN_EVENT_STATE_CHANGED) {

            HandleStateChangedEvent();
        }


        // ========================================================
        // PLAYBACK DRAINED
        // ========================================================

        if (bits & MAIN_EVENT_PLAYBACK_DRAINED) {

            if (
                pending_listening_start_ &&
                GetDeviceState() ==
                    kDeviceStateListening &&
                audio_service_.IsPlaybackIdle()
            ) {

                pending_listening_start_ = false;

                StartListeningAudio();
            }
        }


        // ========================================================
        // TOGGLE CHAT
        // ========================================================

        if (bits & MAIN_EVENT_TOGGLE_CHAT) {

            HandleToggleChatEvent();
        }


        // ========================================================
        // START LISTENING
        // ========================================================

        if (bits & MAIN_EVENT_START_LISTENING) {

            HandleStartListeningEvent();
        }


        // ========================================================
        // STOP LISTENING
        // ========================================================

        if (bits & MAIN_EVENT_STOP_LISTENING) {

            HandleStopListeningEvent();
        }


        // ========================================================
        // SEND AUDIO TO SERVER
        // ========================================================

        if (bits & MAIN_EVENT_SEND_AUDIO) {

            while (
                auto packet =
                    audio_service_.PopPacketFromSendQueue()
            ) {

                if (
                    protocol_ &&
                    !protocol_->SendAudio(
                        std::move(packet)
                    )
                ) {

                    while (
                        audio_service_.PopPacketFromSendQueue()
                    )
                        ;

                    break;
                }
            }
        }


        // ========================================================
        // WAKE WORD
        // ========================================================

        if (bits & MAIN_EVENT_WAKE_WORD_DETECTED) {

            HandleWakeWordDetectedEvent();
        }


        // ========================================================
        // VAD
        // ========================================================

        if (bits & MAIN_EVENT_VAD_CHANGE) {

            if (
                GetDeviceState() ==
                kDeviceStateListening
            ) {

                auto led =
                    Board::GetInstance().GetLed();

                led->OnStateChanged();
            }
        }


        // ========================================================
        // SCHEDULED MAIN TASKS
        // ========================================================

        if (bits & MAIN_EVENT_SCHEDULE) {

            std::unique_lock<std::mutex> lock(
                mutex_
            );

            auto tasks =
                std::move(main_tasks_);

            lock.unlock();


            for (auto& task : tasks) {

                task();
            }
        }


        // ========================================================
        // CLOCK
        // ========================================================

        if (bits & MAIN_EVENT_CLOCK_TICK) {

            clock_ticks_++;

            auto display =
                Board::GetInstance().GetDisplay();

            display->UpdateStatusBar();


            if (clock_ticks_ % 10 == 0) {

                SystemInfo::PrintHeapStats();
            }
        }
    }
}


/*
 * ================================================================
 * NETWORK CONNECTED
 * ================================================================
 */

void Application::HandleNetworkConnectedEvent() {

    ESP_LOGI(
        TAG,
        "Network connected"
    );


    auto state =
        GetDeviceState();


    if (
        state == kDeviceStateStarting ||
        state == kDeviceStateWifiConfiguring
    ) {

        SetDeviceState(
            kDeviceStateActivating
        );


        if (activation_task_handle_ != nullptr) {

            ESP_LOGW(
                TAG,
                "Activation task already running"
            );

            return;
        }


        xTaskCreate(
            [](void* arg) {

                Application* app =
                    static_cast<Application*>(arg);

                app->ActivationTask();

                app->activation_task_handle_ =
                    nullptr;

                vTaskDelete(NULL);
            },

            "activation",
            4096 * 2,
            this,
            2,
            &activation_task_handle_
        );
    }


    auto display =
        Board::GetInstance().GetDisplay();

    display->UpdateStatusBar(true);
}


/*
 * ================================================================
 * NETWORK DISCONNECTED
 * ================================================================
 */

void Application::HandleNetworkDisconnectedEvent() {

    auto state =
        GetDeviceState();


    /*
     * If a conversation is active, close the network audio
     * channel. Offline commands will remain available from idle.
     */
    if (
        (
            state == kDeviceStateConnecting ||
            state == kDeviceStateListening ||
            state == kDeviceStateSpeaking
        ) &&
        protocol_ != nullptr
    ) {

        ESP_LOGI(
            TAG,
            "Closing audio channel due to network disconnection"
        );

        protocol_->CloseAudioChannel();
    }


    auto display =
        Board::GetInstance().GetDisplay();

    display->UpdateStatusBar(true);
}


/*
 * ================================================================
 * ACTIVATION DONE
 * ================================================================
 */

void Application::HandleActivationDoneEvent() {

    ESP_LOGI(
        TAG,
        "Activation done"
    );


    SystemInfo::PrintHeapStats();


    SetDeviceState(
        kDeviceStateIdle
    );


    has_server_time_ =
        ota_->HasServerTime();


    auto display =
        Board::GetInstance().GetDisplay();


    std::string message =
        std::string(Lang::Strings::VERSION) +
        ota_->GetCurrentVersion();


    display->ShowNotification(
        message.c_str()
    );


    display->SetChatMessage(
        "system",
        ""
    );


    ota_.reset();


    auto& board =
        Board::GetInstance();

    board.SetPowerSaveLevel(
        PowerSaveLevel::LOW_POWER
    );


    Schedule(
        [this]() {

            audio_service_.PlaySound(
                Lang::Sounds::OGG_SUCCESS
            );
        }
    );
}


/*
 * ================================================================
 * ACTIVATION TASK
 * ================================================================
 */

void Application::ActivationTask() {

    ota_ =
        std::make_unique<Ota>();


    CheckAssetsVersion();

    CheckNewVersion();

    InitializeProtocol();


    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_ACTIVATION_DONE
    );
}


/*
 * ================================================================
 * ASSETS
 * ================================================================
 */

void Application::CheckAssetsVersion() {

    if (assets_version_checked_) {

        return;
    }


    assets_version_checked_ = true;


    auto& board =
        Board::GetInstance();

    auto display =
        board.GetDisplay();

    auto& assets =
        Assets::GetInstance();


    if (!assets.partition_valid()) {

        ESP_LOGW(
            TAG,
            "Assets partition is disabled for board %s",
            BOARD_NAME
        );

        return;
    }


    Settings settings(
        "assets",
        true
    );


    std::string download_url =
        settings.GetString(
            "download_url"
        );


    if (!download_url.empty()) {

        settings.EraseKey(
            "download_url"
        );


        char message[256];

        snprintf(
            message,
            sizeof(message),
            Lang::Strings::FOUND_NEW_ASSETS,
            download_url.c_str()
        );


        Alert(
            Lang::Strings::LOADING_ASSETS,
            message,
            "cloud_download",
            Lang::Sounds::OGG_UPGRADE
        );


        vTaskDelay(
            pdMS_TO_TICKS(3000)
        );


        SetDeviceState(
            kDeviceStateUpgrading
        );


        board.SetPowerSaveLevel(
            PowerSaveLevel::PERFORMANCE
        );


        display->SetChatMessage(
            "system",
            Lang::Strings::PLEASE_WAIT
        );


        bool success =
            assets.Download(
                download_url,
                [this, display](
                    int progress,
                    size_t speed) -> void {

                    char buffer[32];

                    snprintf(
                        buffer,
                        sizeof(buffer),
                        "%d%% %uKB/s",
                        progress,
                        speed / 1024
                    );


                    Schedule(
                        [display,
                         message = std::string(buffer)]() {

                            display->SetChatMessage(
                                "system",
                                message.c_str()
                            );
                        }
                    );
                }
            );


        board.SetPowerSaveLevel(
            PowerSaveLevel::LOW_POWER
        );


        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );


        if (!success) {

            Alert(
                Lang::Strings::ERROR,
                Lang::Strings::DOWNLOAD_ASSETS_FAILED,
                "cancel",
                Lang::Sounds::OGG_EXCLAMATION
            );


            vTaskDelay(
                pdMS_TO_TICKS(2000)
            );


            SetDeviceState(
                kDeviceStateActivating
            );

            return;
        }
    }


    assets.Apply();


    display->SetChatMessage(
        "system",
        ""
    );


    display->SetEmotion(
        "robot_2"
    );
}


/*
 * ================================================================
 * OTA / VERSION CHECK
 * ================================================================
 */

void Application::CheckNewVersion() {

    /*
     * OTA/version checking must never prevent the device from
     * becoming usable when the internet is unavailable.
     *
     * For hybrid/offline mode we do a limited number of attempts
     * and then continue with normal operation.
     */

    const int MAX_RETRY = 2;

    int retry_count = 0;

    int retry_delay = 5;


    auto& board =
        Board::GetInstance();


    while (true) {

        auto display =
            board.GetDisplay();


        display->SetStatus(
            Lang::Strings::CHECKING_NEW_VERSION
        );


        ESP_LOGI(
            TAG,
            "Checking XiaoZhi OTA/version server..."
        );


        esp_err_t err =
            ota_->CheckVersion();


        /*
         * --------------------------------------------------------
         * SERVER UNAVAILABLE
         * --------------------------------------------------------
         */

        if (err != ESP_OK) {

            retry_count++;


            ESP_LOGW(
                TAG,
                "OTA/version server unavailable: error=%d (%d/%d)",
                err,
                retry_count,
                MAX_RETRY
            );


            /*
             * Do NOT sit here for a long exponential retry cycle.
             *
             * After the final attempt, return immediately.
             * ActivationTask() will continue to InitializeProtocol()
             * and then finish activation.
             */

            if (retry_count >= MAX_RETRY) {

                ESP_LOGW(
                    TAG,
                    "OTA check skipped - continuing without online update check"
                );


                /*
                 * This is intentional for hybrid mode.
                 */
                return;
            }


            char error_message[128];


            snprintf(
                error_message,
                sizeof(error_message),
                "code=%d, url=%s",
                err,
                ota_->GetCheckVersionUrl().c_str()
            );


            char buffer[256];


            snprintf(
                buffer,
                sizeof(buffer),
                Lang::Strings::CHECK_NEW_VERSION_FAILED,
                retry_delay,
                error_message
            );


            Alert(
                Lang::Strings::ERROR,
                buffer,
                "cloud_off",
                Lang::Sounds::OGG_EXCLAMATION
            );


            ESP_LOGW(
                TAG,
                "Retrying OTA check in %d seconds",
                retry_delay
            );


            for (
                int i = 0;
                i < retry_delay;
                ++i
            ) {

                vTaskDelay(
                    pdMS_TO_TICKS(1000)
                );
            }


            retry_delay = 5;

            continue;
        }


        /*
         * --------------------------------------------------------
         * SERVER AVAILABLE
         * --------------------------------------------------------
         */

        ESP_LOGI(
            TAG,
            "OTA/version server is available"
        );


        retry_count = 0;


        /*
         * --------------------------------------------------------
         * FIRMWARE UPDATE
         * --------------------------------------------------------
         */

        if (ota_->HasNewVersion()) {

            ESP_LOGI(
                TAG,
                "New firmware version available"
            );


            if (
                UpgradeFirmware(
                    ota_->GetFirmwareUrl(),
                    ota_->GetFirmwareVersion()
                )
            ) {

                return;
            }


            ESP_LOGW(
                TAG,
                "Firmware upgrade failed - continuing with current firmware"
            );
        }


        /*
         * Current firmware is considered valid.
         */
        ota_->MarkCurrentVersionValid();


        /*
         * --------------------------------------------------------
         * ACTIVATION
         * --------------------------------------------------------
         */

        if (
            !ota_->HasActivationCode() &&
            !ota_->HasActivationChallenge()
        ) {

            ESP_LOGI(
                TAG,
                "No activation required"
            );


            break;
        }


        display->SetStatus(
            Lang::Strings::ACTIVATION
        );


        if (
            ota_->HasActivationCode()
        ) {

            ShowActivationCode(
                ota_->GetActivationCode(),
                ota_->GetActivationMessage()
            );
        }


        /*
         * Perform activation attempts.
         */
        for (
            int i = 0;
            i < 5;
            ++i
        ) {

            ESP_LOGI(
                TAG,
                "Activating... %d/5",
                i + 1
            );


            esp_err_t activate_err =
                ota_->Activate();


            if (
                activate_err == ESP_OK
            ) {

                ESP_LOGI(
                    TAG,
                    "Activation successful"
                );


                break;

            } else if (
                activate_err ==
                ESP_ERR_TIMEOUT
            ) {

                ESP_LOGW(
                    TAG,
                    "Activation timed out"
                );


                vTaskDelay(
                    pdMS_TO_TICKS(3000)
                );

            } else {

                ESP_LOGW(
                    TAG,
                    "Activation failed: %d",
                    activate_err
                );


                vTaskDelay(
                    pdMS_TO_TICKS(3000)
                );
            }
        }


        /*
         * Leave this routine after the activation attempt.
         *
         * We do not want startup to be blocked forever by the
         * network.
         */
        break;
    }
}



/*
 * ================================================================
 * PROTOCOL INITIALIZATION
 * ================================================================
 */

void Application::InitializeProtocol() {

    auto& board =
        Board::GetInstance();

    auto display =
        board.GetDisplay();

    auto codec =
        board.GetAudioCodec();


    display->SetStatus(
        Lang::Strings::LOADING_PROTOCOL
    );


    if (ota_->HasMqttConfig()) {

        protocol_ =
            std::make_unique<MqttProtocol>();

    } else if (
        ota_->HasWebsocketConfig()
    ) {

        protocol_ =
            std::make_unique<WebsocketProtocol>();

    } else {

        ESP_LOGW(
            TAG,
            "No protocol specified in OTA config, using MQTT"
        );

        protocol_ =
            std::make_unique<MqttProtocol>();
    }


    // ============================================================
    // PROTOCOL CALLBACKS
    // ============================================================

    protocol_->OnConnected(
        [this]() {

            ESP_LOGI(
                TAG,
                "Protocol connected"
            );

            DismissAlert();
        }
    );


    protocol_->OnNetworkError(
        [this](const std::string& message) {

            last_error_message_ =
                message;

            ESP_LOGW(
                TAG,
                "Protocol network error: %s",
                message.c_str()
            );

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_ERROR
            );
        }
    );


    protocol_->OnIncomingAudio(
        [this](
            std::unique_ptr<AudioStreamPacket> packet) {

            if (
                GetDeviceState() ==
                kDeviceStateSpeaking
            ) {

                audio_service_.PushPacketToDecodeQueue(
                    std::move(packet)
                );
            }
        }
    );


    protocol_->OnAudioChannelOpened(
        [this, codec, &board]() {

            board.SetPowerSaveLevel(
                PowerSaveLevel::PERFORMANCE
            );


            if (
                protocol_->server_sample_rate() !=
                codec->output_sample_rate()
            ) {

                ESP_LOGW(
                    TAG,
                    "Server sample rate %d does not match device output sample rate %d, "
                    "resampling may cause distortion",
                    protocol_->server_sample_rate(),
                    codec->output_sample_rate()
                );
            }
        }
    );


    protocol_->OnAudioChannelClosed(
        [this, &board]() {

            board.SetPowerSaveLevel(
                PowerSaveLevel::LOW_POWER
            );


            Schedule(
                [this]() {

                    auto display =
                        Board::GetInstance().GetDisplay();


                    display->SetChatMessage(
                        "system",
                        ""
                    );


                    SetDeviceState(
                        kDeviceStateIdle
                    );
                }
            );
        }
    );


    // ============================================================
    // INCOMING JSON
    // ============================================================

    protocol_->OnIncomingJson(
        [this, display](const cJSON* root) {

            auto type =
                cJSON_GetObjectItem(
                    root,
                    "type"
                );


            if (!cJSON_IsString(type)) {

                ESP_LOGW(
                    TAG,
                    "Incoming JSON message has no type"
                );

                return;
            }


            if (
                strcmp(
                    type->valuestring,
                    "tts"
                ) == 0
            ) {

                auto state =
                    cJSON_GetObjectItem(
                        root,
                        "state"
                    );


                if (!cJSON_IsString(state)) {

                    return;
                }


                if (
                    strcmp(
                        state->valuestring,
                        "start"
                    ) == 0
                ) {

                    Schedule(
                        [this]() {

                            aborted_ = false;

                            SetDeviceState(
                                kDeviceStateSpeaking
                            );
                        }
                    );

                } else if (
                    strcmp(
                        state->valuestring,
                        "stop"
                    ) == 0
                ) {

                    Schedule(
                        [this]() {

                            if (
                                GetDeviceState() ==
                                kDeviceStateSpeaking
                            ) {

                                if (
                                    listening_mode_ ==
                                    kListeningModeManualStop
                                ) {

                                    SetDeviceState(
                                        kDeviceStateIdle
                                    );

                                } else {

                                    SetDeviceState(
                                        kDeviceStateListening
                                    );
                                }
                            }
                        }
                    );

                } else if (
                    strcmp(
                        state->valuestring,
                        "sentence_start"
                    ) == 0
                ) {

                    auto text =
                        cJSON_GetObjectItem(
                            root,
                            "text"
                        );


                    if (
                        cJSON_IsString(text)
                    ) {

                        std::vector<TextGlyph> glyphs;

                        uint8_t bpp = 0;


                        if (
                            !TextGlyphPayload::Parse(
                                root,
                                glyphs,
                                bpp
                            )
                        ) {

                            glyphs.clear();
                        }


                        ESP_LOGI(
                            TAG,
                            "<< %s",
                            text->valuestring
                        );


                        Schedule(
                            [display,
                             message = std::string(
                                 text->valuestring
                             ),
                             glyphs = std::move(glyphs),
                             bpp]() {

                                display->AddTextGlyphs(
                                    glyphs,
                                    bpp
                                );


                                display->SetChatMessage(
                                    "assistant",
                                    message.c_str()
                                );
                            }
                        );
                    }
                }

            } else if (
                strcmp(
                    type->valuestring,
                    "stt"
                ) == 0
            ) {

                auto text =
                    cJSON_GetObjectItem(
                        root,
                        "text"
                    );


                if (
                    cJSON_IsString(text)
                ) {

                    std::vector<TextGlyph> glyphs;

                    uint8_t bpp = 0;


                    if (
                        !TextGlyphPayload::Parse(
                            root,
                            glyphs,
                            bpp
                        )
                    ) {

                        glyphs.clear();
                    }


                    ESP_LOGI(
                        TAG,
                        ">> %s",
                        text->valuestring
                    );


                    Schedule(
                        [display,
                         message = std::string(
                             text->valuestring
                         ),
                         glyphs = std::move(glyphs),
                         bpp]() {

                            display->AddTextGlyphs(
                                glyphs,
                                bpp
                            );


                            display->SetChatMessage(
                                "user",
                                message.c_str()
                            );
                        }
                    );
                }

            } else if (
                strcmp(
                    type->valuestring,
                    "llm"
                ) == 0
            ) {

                auto emotion =
                    cJSON_GetObjectItem(
                        root,
                        "emotion"
                    );


                if (
                    cJSON_IsString(emotion)
                ) {

                    Schedule(
                        [
                            display,
                            emotion_str = std::string(
                                emotion->valuestring
                            )
                        ]() {

                            display->SetEmotion(
                                emotion_str.c_str()
                            );
                        }
                    );
                }

            } else if (
                strcmp(
                    type->valuestring,
                    "mcp"
                ) == 0
            ) {

                auto payload =
                    cJSON_GetObjectItem(
                        root,
                        "payload"
                    );


                if (
                    cJSON_IsObject(payload)
                ) {

                    McpServer::GetInstance()
                        .ParseMessage(payload);
                }

            } else if (
                strcmp(
                    type->valuestring,
                    "system"
                ) == 0
            ) {

                auto command =
                    cJSON_GetObjectItem(
                        root,
                        "command"
                    );


                if (
                    cJSON_IsString(command)
                ) {

                    ESP_LOGI(
                        TAG,
                        "System command: %s",
                        command->valuestring
                    );


                    if (
                        strcmp(
                            command->valuestring,
                            "reboot"
                        ) == 0
                    ) {

                        Schedule(
                            [this]() {
                                Reboot();
                            }
                        );

                    } else {

                        ESP_LOGW(
                            TAG,
                            "Unknown system command: %s",
                            command->valuestring
                        );
                    }
                }

            } else if (
                strcmp(
                    type->valuestring,
                    "alert"
                ) == 0
            ) {

                auto status =
                    cJSON_GetObjectItem(
                        root,
                        "status"
                    );

                auto message =
                    cJSON_GetObjectItem(
                        root,
                        "message"
                    );

                auto emotion =
                    cJSON_GetObjectItem(
                        root,
                        "emotion"
                    );


                if (
                    cJSON_IsString(status) &&
                    cJSON_IsString(message) &&
                    cJSON_IsString(emotion)
                ) {

                    Alert(
                        status->valuestring,
                        message->valuestring,
                        emotion->valuestring,
                        Lang::Sounds::OGG_VIBRATION
                    );

                } else {

                    ESP_LOGW(
                        TAG,
                        "Alert command requires status, message and emotion"
                    );
                }

#if CONFIG_RECEIVE_CUSTOM_MESSAGE

            } else if (
                strcmp(
                    type->valuestring,
                    "custom"
                ) == 0
            ) {

                auto payload =
                    cJSON_GetObjectItem(
                        root,
                        "payload"
                    );


                ESP_LOGI(
                    TAG,
                    "Received custom message: %s",
                    cJSON_PrintUnformatted(root)
                );


                if (
                    cJSON_IsObject(payload)
                ) {

                    Schedule(
                        [
                            this,
                            display,
                            payload_str =
                                std::string(
                                    cJSON_PrintUnformatted(
                                        payload
                                    )
                                )
                        ]() {

                            display->SetChatMessage(
                                "system",
                                payload_str.c_str()
                            );
                        }
                    );

                } else {

                    ESP_LOGW(
                        TAG,
                        "Invalid custom message format: missing payload"
                    );
                }

#endif

            } else {

                ESP_LOGW(
                    TAG,
                    "Unknown message type: %s",
                    type->valuestring
                );
            }
        }
    );


    protocol_->Start();
}


/*
 * ================================================================
 * ACTIVATION CODE
 * ================================================================
 */




void Application::ShowActivationCode(
    const std::string& code,
    const std::string& message) {

    // Preserve the activation prompt and display.
    // Skip individual digit audio playback.
    (void)code;

    Alert(
        Lang::Strings::ACTIVATION,
        message.c_str(),
        "link",
        Lang::Sounds::OGG_ACTIVATION
    );
}





/*
 * ================================================================
 * ALERTS
 * ================================================================
 */

void Application::Alert(
    const char* status,
    const char* message,
    const char* emotion,
    const std::string_view& sound) {

    ESP_LOGW(
        TAG,
        "Alert [%s] %s: %s",
        emotion,
        status,
        message
    );


    auto display =
        Board::GetInstance().GetDisplay();


    display->SetStatus(
        status
    );


    display->SetEmotion(
        emotion
    );


    display->SetChatMessage(
        "system",
        message
    );


    if (!sound.empty()) {

        audio_service_.PlaySound(
            sound
        );
    }
}


void Application::DismissAlert() {

    if (
        GetDeviceState() ==
        kDeviceStateIdle
    ) {

        auto display =
            Board::GetInstance().GetDisplay();


        display->SetStatus(
            Lang::Strings::STANDBY
        );


        display->SetEmotion(
            "neutral"
        );


        display->SetChatMessage(
            "system",
            ""
        );
    }
}


/*
 * ================================================================
 * USER INTERACTION
 * ================================================================
 */

void Application::ToggleChatState() {

    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_TOGGLE_CHAT
    );
}


void Application::StartListening() {

    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_START_LISTENING
    );
}


void Application::StopListening() {

    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_STOP_LISTENING
    );
}


/*
 * ================================================================
 * TOGGLE CHAT
 * ================================================================
 */

void Application::HandleToggleChatEvent() {

    auto state =
        GetDeviceState();


    if (
        state ==
        kDeviceStateActivating
    ) {

        SetDeviceState(
            kDeviceStateIdle
        );

        return;
    }


    if (
        state ==
        kDeviceStateWifiConfiguring
    ) {

        audio_service_.EnableAudioTesting(
            true
        );

        SetDeviceState(
            kDeviceStateAudioTesting
        );

        return;
    }


    if (
        state ==
        kDeviceStateAudioTesting
    ) {

        audio_service_.EnableAudioTesting(
            false
        );

        SetDeviceState(
            kDeviceStateWifiConfiguring
        );

        return;
    }


    if (!protocol_) {

        ESP_LOGE(
            TAG,
            "Protocol not initialized"
        );

#if CONFIG_USE_OFFLINE_COMMANDS

        ESP_LOGI(
            TAG,
            "Offline commands remain available"
        );

#endif

        return;
    }


    if (
        state ==
        kDeviceStateIdle
    ) {

        ListeningMode mode =
            GetDefaultListeningMode();


        if (
            !protocol_->IsAudioChannelOpened()
        ) {

            SetDeviceState(
                kDeviceStateConnecting
            );


            Schedule(
                [this, mode]() {
                    ContinueOpenAudioChannel(
                        mode
                    );
                }
            );

            return;
        }


        SetListeningMode(
            mode
        );

    } else if (
        state ==
        kDeviceStateSpeaking
    ) {

        AbortSpeaking(
            kAbortReasonNone
        );

    } else if (
        state ==
        kDeviceStateListening
    ) {

        protocol_->CloseAudioChannel();
    }
}


/*
 * ================================================================
 * OPEN AUDIO CHANNEL
 * ================================================================
 */

void Application::ContinueOpenAudioChannel(
    ListeningMode mode) {

    if (
        GetDeviceState() !=
        kDeviceStateConnecting
    ) {

        return;
    }


    auto& board =
        Board::GetInstance();


    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );


    if (
        !protocol_->IsAudioChannelOpened()
    ) {

        if (
            !protocol_->OpenAudioChannel()
        ) {

            ESP_LOGW(
                TAG,
                "Unable to open online audio channel"
            );


#if CONFIG_USE_OFFLINE_COMMANDS

            /*
             * ----------------------------------------------------
             * HYBRID FALLBACK
             * ----------------------------------------------------
             *
             * Eva was recognized.
             *
             * The online XiaoZhi channel could not be opened.
             *
             * Arm the next offline command so that:
             *
             *     "turn on led"
             *
             * or
             *
             *     "turn off led"
             *
             * can be executed locally.
             */

            g_offline_command_armed = true;


            ESP_LOGI(
                TAG,
                "HYBRID: online server unavailable, offline mode armed"
            );


            auto display =
                Board::GetInstance().GetDisplay();


            display->ShowNotification(
                "Offline mode",
                3000
            );

#endif


            /*
             * Return to idle. The idle state handler will re-enable
             * the MultiNet detector.
             */
            SetDeviceState(
                kDeviceStateIdle
            );

            return;
        }
    }


    SetListeningMode(
        mode
    );
}


/*
 * ================================================================
 * MANUAL LISTENING
 * ================================================================
 */

void Application::HandleStartListeningEvent() {

    auto state =
        GetDeviceState();


    if (
        state ==
        kDeviceStateActivating
    ) {

        SetDeviceState(
            kDeviceStateIdle
        );

        return;
    }


    if (
        state ==
        kDeviceStateWifiConfiguring
    ) {

        audio_service_.EnableAudioTesting(
            true
        );


        SetDeviceState(
            kDeviceStateAudioTesting
        );

        return;
    }


    if (!protocol_) {

        ESP_LOGE(
            TAG,
            "Protocol not initialized"
        );

        return;
    }


    if (
        state ==
        kDeviceStateIdle
    ) {

        if (
            !protocol_->IsAudioChannelOpened()
        ) {

            SetDeviceState(
                kDeviceStateConnecting
            );


            Schedule(
                [this]() {

                    ContinueOpenAudioChannel(
                        kListeningModeManualStop
                    );
                }
            );


            return;
        }


        SetListeningMode(
            kListeningModeManualStop
        );

    } else if (
        state ==
        kDeviceStateSpeaking
    ) {

        AbortSpeaking(
            kAbortReasonNone
        );


        SetListeningMode(
            kListeningModeManualStop
        );
    }
}


/*
 * ================================================================
 * STOP LISTENING
 * ================================================================
 */

void Application::HandleStopListeningEvent() {

    auto state =
        GetDeviceState();


    if (
        state ==
        kDeviceStateAudioTesting
    ) {

        audio_service_.EnableAudioTesting(
            false
        );


        SetDeviceState(
            kDeviceStateWifiConfiguring
        );


        return;
    }


    if (
        state ==
        kDeviceStateListening
    ) {

        if (protocol_) {

            protocol_->SendStopListening();
        }


        SetDeviceState(
            kDeviceStateIdle
        );
    }
}


/*
 * ================================================================
 * WAKE WORD DETECTED
 * ================================================================
 */

void Application::HandleWakeWordDetectedEvent() {

#if CONFIG_USE_OFFLINE_COMMANDS

    /*
     * ============================================================
     * ALREADY IN OFFLINE MODE
     * ============================================================
     *
     * The server has previously failed.
     *
     * In this situation, another "Eva" must NOT try to connect
     * to the XiaoZhi server again.
     *
     * We simply keep offline mode active and re-arm MultiNet.
     */
    if (g_offline_command_armed) {

        ESP_LOGI(
            TAG,
            "Eva detected while offline mode is active"
        );

        ESP_LOGI(
            TAG,
            "Not reconnecting to server - staying in offline mode"
        );

        auto display =
            Board::GetInstance().GetDisplay();

        display->ShowNotification(
            "Offline mode",
            3000
        );

        /*
         * CustomWakeWord stops itself immediately after detecting
         * the wake word. Start it again so it can hear:
         *
         *     turn on led
         *     turn off led
         */
        audio_service_.EnableWakeWordDetection(
            true
        );

        return;
    }

#endif


    /*
     * ============================================================
     * NO PROTOCOL
     * ============================================================
     */

    if (!protocol_) {

#if CONFIG_USE_OFFLINE_COMMANDS

        ESP_LOGW(
            TAG,
            "Eva detected but online protocol is unavailable"
        );


        g_offline_command_armed = true;


        ESP_LOGI(
            TAG,
            "HYBRID: offline mode armed"
        );


        auto display =
            Board::GetInstance().GetDisplay();

        display->ShowNotification(
            "Offline mode",
            3000
        );


        /*
         * Re-arm MultiNet after Eva was detected.
         */
        audio_service_.EnableWakeWordDetection(
            true
        );

#endif

        return;
    }


    /*
     * ============================================================
     * NORMAL ONLINE MODE
     * ============================================================
     */

    auto state =
        GetDeviceState();


    auto wake_word =
        audio_service_.GetLastWakeWord();


    ESP_LOGI(
        TAG,
        "Wake word detected: %s (state: %d)",
        wake_word.c_str(),
        static_cast<int>(state)
    );


    /*
     * Do NOT clear g_offline_command_armed here.
     *
     * If it is true, the function would have already returned
     * above.
     *
     * A network-connected event is responsible for clearing it.
     */


    if (
        state ==
        kDeviceStateIdle
    ) {

        BeginWakeWordInvoke(
            wake_word
        );

    } else if (
        state == kDeviceStateSpeaking ||
        state == kDeviceStateListening
    ) {

        AbortSpeaking(
            kAbortReasonWakeWordDetected
        );


        /*
         * Clear old audio.
         */
        while (
            audio_service_.PopPacketFromSendQueue()
        )
            ;


        if (
            state ==
            kDeviceStateListening
        ) {

            protocol_->SendStartListening(
                GetDefaultListeningMode()
            );


            audio_service_.ResetDecoder();


            audio_service_.PlaySound(
                Lang::Sounds::OGG_POPUP
            );


            audio_service_.EnableWakeWordDetection(
                true
            );

        } else {

            play_popup_on_listening_ = true;


            SetListeningMode(
                GetDefaultListeningMode()
            );
        }

    } else if (
        state ==
        kDeviceStateActivating
    ) {

        SetDeviceState(
            kDeviceStateIdle
        );
    }
}


/*
 * ================================================================
 * OFFLINE COMMAND DETECTED
 * ================================================================
 */



void Application::HandleCommandDetected(
    const std::string& text,
    const std::string& action) {

#if CONFIG_USE_OFFLINE_COMMANDS

    const auto state = GetDeviceState();

    ESP_LOGI(
        TAG,
        "Local command recognized: text=%s action=%s state=%d",
        text.c_str(),
        action.c_str(),
        static_cast<int>(state)
    );

    // Only execute local commands while the application is idle.
    if (state != kDeviceStateIdle) {
        ESP_LOGW(
            TAG,
            "Ignoring local command because the device is busy"
        );
        return;
    }

    if (!command_handler_) {
        ESP_LOGE(
            TAG,
            "No local command handler registered for: %s",
            action.c_str()
        );
        return;
    }

    // Execute the recognized command exactly once.
    // Do not require g_offline_command_armed here.
    command_handler_(text, action);

    // Keep local command recognition available.
    audio_service_.EnableWakeWordDetection(true);

#else

    (void)text;
    (void)action;

#endif
}




/*
 * ================================================================
 * COMMAND HANDLER REGISTRATION
 * ================================================================
 */

void Application::RegisterCommandHandler(
    std::function<
        void(
            const std::string& text,
            const std::string& action
        )> callback) {

    command_handler_ =
        std::move(callback);
}


/*
 * ================================================================
 * LOCAL TTS
 * ================================================================
 */

void Application::SpeakLocalText(
    const std::string& text) {

    /*
     * The board's offline worker task calls this function, so
     * blocking TTS is safe here.
     */
    TtsPlayer::GetInstance().Speak(
        text
    );
}


/*
 * ================================================================
 * BEGIN WAKE WORD INVOKE
 * ================================================================
 */

void Application::BeginWakeWordInvoke(
    const std::string& wake_word) {

#if CONFIG_USE_OFFLINE_COMMANDS

    /*
     * Do not inherit a previous offline session.
     */
    g_offline_command_armed = false;

#endif


    /*
     * Encode the wake-word audio for the online protocol.
     */
    audio_service_.EncodeWakeWord();


    /*
     * Always enter Connecting first.
     */
    if (
        !SetDeviceState(
            kDeviceStateConnecting
        )
    ) {

        /*
         * If transition failed, restart the detector.
         */
        audio_service_.EnableWakeWordDetection(
            true
        );

        return;
    }


    if (
        !protocol_->IsAudioChannelOpened()
    ) {

        /*
         * OpenAudioChannel() may block.
         * Run it through the main-task scheduler after the
         * Connecting state is processed.
         */
        Schedule(
            [this, wake_word]() {

                ContinueWakeWordInvoke(
                    wake_word
                );
            }
        );


        return;
    }


    ContinueWakeWordInvoke(
        wake_word
    );
}


/*
 * ================================================================
 * CONTINUE WAKE WORD INVOKE
 * ================================================================
 */

void Application::ContinueWakeWordInvoke(
    const std::string& wake_word) {

    if (
        GetDeviceState() !=
        kDeviceStateConnecting
    ) {

        return;
    }


    auto& board =
        Board::GetInstance();


    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );


    /*
     * ============================================================
     * TRY ONLINE SERVER
     * ============================================================
     */

    if (
        !protocol_->IsAudioChannelOpened()
    ) {

        if (
            !protocol_->OpenAudioChannel()
        ) {

            ESP_LOGW(
                TAG,
                "Online server connection failed after wake word"
            );


#if CONFIG_USE_OFFLINE_COMMANDS

            /*
             * ====================================================
             * OFFLINE FALLBACK
             * ====================================================
             */

            g_offline_command_armed = true;


            ESP_LOGI(
                TAG,
                "HYBRID FALLBACK ENABLED"
            );


            ESP_LOGI(
                TAG,
                "Waiting for offline command..."
            );


            auto display =
                Board::GetInstance().GetDisplay();


            display->ShowNotification(
                "Offline mode",
                3000
            );

#endif


            /*
             * Returning to idle causes HandleStateChangedEvent()
             * to restart wake-word / MultiNet processing.
             */
            SetDeviceState(
                kDeviceStateIdle
            );


            return;
        }
    }


    /*
     * ============================================================
     * ONLINE SERVER IS AVAILABLE
     * ============================================================
     */

    ESP_LOGI(
        TAG,
        "Online server connected"
    );


    ESP_LOGI(
        TAG,
        "Wake word detected: %s",
        wake_word.c_str()
    );


#if CONFIG_SEND_WAKE_WORD_DATA

    /*
     * Send cached wake-word audio.
     */
    while (
        auto packet =
            audio_service_.PopWakeWordPacket()
    ) {

        if (
            !protocol_->SendAudio(
                std::move(packet)
            )
        ) {

            /*
             * Online send failed after the channel opened.
             * Fall back to local mode.
             */
#if CONFIG_USE_OFFLINE_COMMANDS

            ESP_LOGW(
                TAG,
                "Failed to send wake-word packet"
            );

            g_offline_command_armed = true;

            protocol_->CloseAudioChannel();

            SetDeviceState(
                kDeviceStateIdle
            );

#endif

            return;
        }
    }


    /*
     * Tell the XiaoZhi server that the wake word was detected.
     */
    protocol_->SendWakeWordDetected(
        wake_word
    );


    /*
     * Enter normal online listening.
     */
    SetListeningMode(
        GetDefaultListeningMode()
    );


#else

    play_popup_on_listening_ = true;

    SetListeningMode(
        GetDefaultListeningMode()
    );

#endif
}


/*
 * ================================================================
 * STATE CHANGED
 * ================================================================
 */

void Application::HandleStateChangedEvent() {

    DeviceState new_state =
        state_machine_.GetState();


    clock_ticks_ = 0;


    /*
     * Any state change invalidates deferred listening.
     */
    pending_listening_start_ = false;


    auto& board =
        Board::GetInstance();


    auto display =
        board.GetDisplay();


    auto led =
        board.GetLed();


    led->OnStateChanged();


    switch (new_state) {


        // ========================================================
        // IDLE
        // ========================================================

        case kDeviceStateUnknown:
        case kDeviceStateIdle: {

            display->SetStatus(
                Lang::Strings::STANDBY
            );


            display->ClearChatMessages();


            display->SetEmotion(
                "neutral"
            );


            audio_service_.EnableVoiceProcessing(
                false
            );


            /*
             * This is especially important for hybrid mode:
             *
             * after online connection failure we return to idle,
             * then this re-arms MultiNet.
             */
            audio_service_.EnableWakeWordDetection(
                true
            );


            break;
        }


        // ========================================================
        // CONNECTING
        // ========================================================

        case kDeviceStateConnecting:

            display->SetStatus(
                Lang::Strings::CONNECTING
            );


            display->SetEmotion(
                "neutral"
            );


            display->SetChatMessage(
                "system",
                ""
            );


            break;


        // ========================================================
        // LISTENING
        // ========================================================

        case kDeviceStateListening:

            display->SetStatus(
                Lang::Strings::LISTENING
            );


            display->SetEmotion(
                "neutral"
            );


            if (
                play_popup_on_listening_ ||
                !audio_service_.IsAudioProcessorRunning()
            ) {

                if (
                    listening_mode_ ==
                        kListeningModeAutoStop &&
                    !audio_service_.IsPlaybackIdle()
                ) {

                    pending_listening_start_ = true;

                } else {

                    StartListeningAudio();
                }

            } else {

                ConfigureWakeWordForListening();
            }


            break;


        // ========================================================
        // SPEAKING
        // ========================================================

        case kDeviceStateSpeaking:

            display->SetStatus(
                Lang::Strings::SPEAKING
            );


            if (
                listening_mode_ !=
                kListeningModeRealtime
            ) {

                audio_service_.EnableVoiceProcessing(
                    false
                );


                /*
                 * Only AFE wake word is usable while speaking.
                 */
                audio_service_.EnableWakeWordDetection(
                    audio_service_.IsAfeWakeWord()
                );
            }


            audio_service_.ResetDecoder();


            break;


        // ========================================================
        // WIFI CONFIG
        // ========================================================

        case kDeviceStateWifiConfiguring:

            audio_service_.EnableVoiceProcessing(
                false
            );


            audio_service_.EnableWakeWordDetection(
                false
            );


            break;


        default:

            break;
    }
}


/*
 * ================================================================
 * START LISTENING AUDIO
 * ================================================================
 */

void Application::StartListeningAudio() {

    if (
        GetDeviceState() !=
        kDeviceStateListening
    ) {

        return;
    }


    /*
     * This is only called for online listening, so protocol should
     * exist here.
     */
    if (!protocol_) {

        ESP_LOGW(
            TAG,
            "Cannot start listening: protocol unavailable"
        );

        SetDeviceState(
            kDeviceStateIdle
        );

        return;
    }


    protocol_->SendStartListening(
        listening_mode_
    );


    audio_service_.EnableVoiceProcessing(
        true
    );


    ConfigureWakeWordForListening();


    if (play_popup_on_listening_) {

        play_popup_on_listening_ = false;


        audio_service_.PlaySound(
            Lang::Sounds::OGG_POPUP
        );
    }
}


/*
 * ================================================================
 * WAKE WORD CONFIGURATION DURING LISTENING
 * ================================================================
 */

void Application::ConfigureWakeWordForListening() {

#ifdef CONFIG_WAKE_WORD_DETECTION_IN_LISTENING

    audio_service_.EnableWakeWordDetection(
        audio_service_.IsAfeWakeWord()
    );

#else

    audio_service_.EnableWakeWordDetection(
        false
    );

#endif
}


/*
 * ================================================================
 * SCHEDULE
 * ================================================================
 */

void Application::Schedule(
    std::function<void()>&& callback) {

    {
        std::lock_guard<std::mutex> lock(
            mutex_
        );

        main_tasks_.push_back(
            std::move(callback)
        );
    }


    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_SCHEDULE
    );
}


/*
 * ================================================================
 * ABORT SPEAKING
 * ================================================================
 */

void Application::AbortSpeaking(
    AbortReason reason) {

    ESP_LOGI(
        TAG,
        "Abort speaking"
    );


    aborted_ = true;


    if (protocol_) {

        protocol_->SendAbortSpeaking(
            reason
        );
    }
}


/*
 * ================================================================
 * LISTENING MODE
 * ================================================================
 */

void Application::SetListeningMode(
    ListeningMode mode) {

    listening_mode_ = mode;


    SetDeviceState(
        kDeviceStateListening
    );
}


ListeningMode Application::GetDefaultListeningMode() const {

    return aec_mode_ == kAecOff
        ? kListeningModeAutoStop
        : kListeningModeRealtime;
}


/*
 * ================================================================
 * REBOOT
 * ================================================================
 */

void Application::Reboot() {

    ESP_LOGI(
        TAG,
        "Rebooting..."
    );


    if (
        protocol_ &&
        protocol_->IsAudioChannelOpened()
    ) {

        protocol_->CloseAudioChannel();
    }


    protocol_.reset();


    audio_service_.Stop();


    vTaskDelay(
        pdMS_TO_TICKS(1000)
    );


    esp_restart();
}


/*
 * ================================================================
 * FIRMWARE UPGRADE
 * ================================================================
 */

bool Application::UpgradeFirmware(
    const std::string& url,
    const std::string& version) {

    auto& board =
        Board::GetInstance();


    auto display =
        board.GetDisplay();


    std::string upgrade_url =
        url;


    std::string version_info =
        version.empty()
            ? "(Manual upgrade)"
            : version;


    if (
        protocol_ &&
        protocol_->IsAudioChannelOpened()
    ) {

        ESP_LOGI(
            TAG,
            "Closing audio channel before firmware upgrade"
        );


        protocol_->CloseAudioChannel();
    }


    ESP_LOGI(
        TAG,
        "Starting firmware upgrade from URL: %s",
        upgrade_url.c_str()
    );


    Alert(
        Lang::Strings::OTA_UPGRADE,
        Lang::Strings::UPGRADING,
        "download",
        Lang::Sounds::OGG_UPGRADE
    );


    vTaskDelay(
        pdMS_TO_TICKS(3000)
    );


    SetDeviceState(
        kDeviceStateUpgrading
    );


    std::string message =
        std::string(
            Lang::Strings::NEW_VERSION
        ) +
        version_info;


    display->SetChatMessage(
        "system",
        message.c_str()
    );


    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );


    audio_service_.Stop();


    vTaskDelay(
        pdMS_TO_TICKS(1000)
    );


    bool upgrade_success =
        Ota::Upgrade(
            upgrade_url,
            [this, display](
                int progress,
                size_t speed) {

                char buffer[32];


                snprintf(
                    buffer,
                    sizeof(buffer),
                    "%d%% %uKB/s",
                    progress,
                    speed / 1024
                );


                Schedule(
                    [display,
                     message = std::string(
                         buffer
                     )]() {

                        display->SetChatMessage(
                            "system",
                            message.c_str()
                        );
                    }
                );
            }
        );


    if (!upgrade_success) {

        ESP_LOGE(
            TAG,
            "Firmware upgrade failed, restarting audio service and continuing operation..."
        );


        audio_service_.Start();


        board.SetPowerSaveLevel(
            PowerSaveLevel::LOW_POWER
        );


        Alert(
            Lang::Strings::ERROR,
            Lang::Strings::UPGRADE_FAILED,
            "cancel",
            Lang::Sounds::OGG_EXCLAMATION
        );


        vTaskDelay(
            pdMS_TO_TICKS(3000)
        );


        return false;

    } else {

        ESP_LOGI(
            TAG,
            "Firmware upgrade successful, rebooting..."
        );


        display->SetChatMessage(
            "system",
            "Upgrade successful, rebooting..."
        );


        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );


        Reboot();


        return true;
    }
}


/*
 * ================================================================
 * EXTERNAL WAKE WORD INVOKE
 * ================================================================
 */

void Application::WakeWordInvoke(
    const std::string& wake_word) {

    if (!protocol_) {

#if CONFIG_USE_OFFLINE_COMMANDS

        /*
         * There is no online protocol.
         * Allow local wake + command operation.
         */
        ESP_LOGW(
            TAG,
            "WakeWordInvoke called without protocol"
        );


        g_offline_command_armed = true;


        audio_service_.EnableWakeWordDetection(
            true
        );

#endif

        return;
    }


    auto state =
        GetDeviceState();


    if (
        state ==
        kDeviceStateIdle
    ) {

        Schedule(
            [this, wake_word]() {

                if (
                    GetDeviceState() ==
                    kDeviceStateIdle
                ) {

                    BeginWakeWordInvoke(
                        wake_word
                    );
                }
            }
        );

    } else if (
        state ==
        kDeviceStateSpeaking
    ) {

        Schedule(
            [this]() {

                AbortSpeaking(
                    kAbortReasonNone
                );
            }
        );

    } else if (
        state ==
        kDeviceStateListening
    ) {

        Schedule(
            [this]() {

                if (protocol_) {

                    protocol_->CloseAudioChannel();
                }
            }
        );
    }
}


/*
 * ================================================================
 * SLEEP
 * ================================================================
 */

bool Application::CanEnterSleepMode() {

    if (
        GetDeviceState() !=
        kDeviceStateIdle
    ) {

        return false;
    }


    if (
        protocol_ &&
        protocol_->IsAudioChannelOpened()
    ) {

        return false;
    }


    if (
        !audio_service_.IsIdle()
    ) {

        return false;
    }


    return true;
}


/*
 * ================================================================
 * MCP
 * ================================================================
 */

void Application::RegisterMcpBroadcastCallback(
    std::function<void(const std::string&)> callback) {

    mcp_broadcast_callback_ =
        std::move(callback);
}


void Application::SendMcpMessage(
    const std::string& payload) {

    Schedule(
        [this, payload]() {

            if (protocol_) {

                protocol_->SendMcpMessage(
                    payload
                );
            }


            if (mcp_broadcast_callback_) {

                mcp_broadcast_callback_(
                    payload
                );
            }
        }
    );
}


/*
 * ================================================================
 * AEC MODE
 * ================================================================
 */

void Application::SetAecMode(
    AecMode mode) {

    aec_mode_ =
        mode;


    Schedule(
        [this]() {

            auto& board =
                Board::GetInstance();

            auto display =
                board.GetDisplay();


            switch (aec_mode_) {

                case kAecOff:

                    audio_service_.EnableDeviceAec(
                        false
                    );


                    display->ShowNotification(
                        Lang::Strings::RTC_MODE_OFF
                    );

                    break;


                case kAecOnServerSide:

                    audio_service_.EnableDeviceAec(
                        false
                    );


                    display->ShowNotification(
                        Lang::Strings::RTC_MODE_ON
                    );

                    break;


                case kAecOnDeviceSide:

                    audio_service_.EnableDeviceAec(
                        true
                    );


                    display->ShowNotification(
                        Lang::Strings::RTC_MODE_ON
                    );

                    break;
            }


            if (
                protocol_ &&
                protocol_->IsAudioChannelOpened()
            ) {

                protocol_->CloseAudioChannel();
            }
        }
    );
}


/*
 * ================================================================
 * SOUND
 * ================================================================
 */

void Application::PlaySound(
    const std::string_view& sound) {

    audio_service_.PlaySound(
        sound
    );
}


/*
 * ================================================================
 * RESET PROTOCOL
 * ================================================================
 */

void Application::ResetProtocol() {

    Schedule(
        [this]() {

            if (
                protocol_ &&
                protocol_->IsAudioChannelOpened()
            ) {

                protocol_->CloseAudioChannel();
            }


            protocol_.reset();
        }
    );
}