# ESP32 小智:离线命令词 + OneNET 环境监测

> 在保留"你好小智"云端对话的同时,实现**纯本地离线命令词识别**与**本地语音合成播报**,
> 并通过 OneNET 平台与 STM32 环境监测设备联动。

[![ESP-IDF](https://img.shields.io/badge/ESP--IDF-v6.0.2-blue)] [![Platform](https://img.shields.io/badge/Platform-ESP32--S3-orange)] [![Language](https://img.shields.io/badge/Language-C%2B%2B%20%2F%20Python-green)]

## ✨ 功能特性

- 🗣️ **离线命令词**:本地 MultiNet 识别"查询环境 / 打开设备 / 关闭设备",无需联网、无需唤醒
- 🔊 **本地语音合成**:esp-tts 中文播报(小乐音色),音色数据打包进 assets 分区
- ☁️ **OneNET 联动**:与 STM32 环境监测设备(温湿度/火焰/震动)双向联动
- 🤖 **云端对话共存**:"你好小智"唤醒 + 云端 AI 对话与离线命令并行互不干扰
- 🚨 **主动告警**:高温/火焰/震动异常自动语音告警
- 📟 **128x128 LCD**:ST7789 彩色屏幕,状态显示与表情动画

## 📦 快速开始

### 环境要求

- ESP-IDF v6.0.2(ESP32-S3)
- Python 3(构建脚本)
- 硬件:ESP32-S3 面包板开发板 + ST7789 LCD + I2S 麦克风 + 功放喇叭

### 构建

```sh
# 配置 IDF 环境后
python scripts/build.py bread-compact-wifi-lcd --name bread-compact-wifi-lcd-128x128
```

### 烧录(分段烧录,切勿使用 merged 全量镜像——会擦除 NVS 丢失 WiFi 配置)

```sh
python -m esptool --chip esp32s3 -p COM5 -b 460800 --before default-reset --after hard-reset write-flash \
  --flash-mode dio --flash-size 16MB --flash-freq 80m \
  0x0 build\bootloader\bootloader.bin \
  0x8000 build\partition_table\partition-table.bin \
  0xd000 build\ota_data_initial.bin \
  0x20000 build\xiaozhi.bin \
  0x800000 build\generated_assets.bin
```

## 🎯 使用示例

| 你说 | 设备行为 |
| --- | --- |
| "查询环境" | 播报:"当前温度 26 度,湿度 60%。未检测到火焰。" |
| "打开设备" | 播报:"好的,已打开风扇",STM32 继电器闭合 |
| "关闭设备" | 播报:"好的,已关闭风扇",STM32 继电器断开 |
| "你好小智,今天天气怎么样?" | 唤醒并进入云端 AI 对话 |

## 🏗️ 技术架构

```
麦克风(I2S 16kHz) ─▶ AFE(WakeNet 唤醒词) ─▶ "你好小智" → 云端对话
                         │ 音频帧
                         ▼
              MultiNet 命令词(mn7_cn) ─▶ 命令回调 ─▶ OneNET HTTP
                         │
                         ▼
                esp-tts 本地合成 ─▶ 重采样 ─▶ I2S 输出
```

核心设计:唤醒词与命令词在**同一 AFE 输出上并行检测**,互不抢占;
命令仅在设备空闲状态响应,2 秒防抖;OneNET 请求与 TTS 合成运行在独立 worker 任务,不阻塞主循环。

## 📂 目录结构

```
main/
├── application.cc            # 状态机、命令分发、TTS 入口
├── audio/
│   ├── engines/              # AFE 音频引擎(唤醒词 + 命令词并行)
│   ├── wake_words/           # 命令词检测器(防抖/回调)
│   ├── tts_player.cc         # 本地 TTS 合成播放
│   └── audio_service.cc      # 播放队列、重采样
├── boards/
│   ├── common/onenet_device.h  # OneNET 签名鉴权/物模型
│   └── bread-compact-wifi-lcd/ # 板卡适配 + 离线命令处理器
└── Kconfig.projbuild         # 离线命令词 / OneNET 配置
scripts/
└── build_default_assets.py   # 模型 + 音色 + 命令表打包
docs/                         # 全套中文文档
```

## 📄 文档

| 序号 | 文档 | 说明 |
| --- | --- | --- |
| 01 | [项目说明文档](docs/01-项目说明文档.md) | 背景、功能、技术架构总览(入门先看) |
| 02 | [项目技术报告](docs/02-项目技术报告.md) | 方案、实现、测试与经验总结 |
| 03 | [硬件接线图与引脚分配](docs/03-硬件接线图与引脚分配.md) | 接线图、引脚表、安全注意 |
| 04 | [OneNET 重新接入指南](docs/04-OneNET重新接入指南.md) | 平台创建产品到接入完整步骤 |
| 05 | [离线命令词功能文档](docs/05-离线命令词功能文档.md) | 命令词实现细节与扩展指南 |
| 06 | [核心代码片段](docs/06-核心代码片段.md) | 关键代码与逐段讲解 |
| 07 | [嵌入式软件工程师面经](docs/07-嵌入式软件工程师面经.md) | 求职面试高频题与项目深挖 |
| 08 | [OneNET × STM32 桥接](docs/onenet-stm32-bridge.md) | 桥接细节与故障排查 |

## 🛠️ 配置

| 配置项 | 默认值 | 说明 |
| --- | --- | --- |
| `CONFIG_USE_OFFLINE_COMMANDS` | n | 离线命令词总开关 |
| `CONFIG_OFFLINE_COMMANDS` | 3 条命令 | 命令词表(拼音,文本,action;) |
| `CONFIG_OFFLINE_COMMAND_THRESHOLD` | 20 | 检测阈值(0.01-0.99) |
| `CONFIG_ONENET_PRODUCT_ID` | - | OneNET 产品 ID |
| `CONFIG_ONENET_ACCESS_KEY` | - | OneNET AccessKey |

## 📌 注意事项

- 离线命令词依赖 MultiNet 模型(`CONFIG_SR_MN_CN_MULTINET7_QUANT=y`),已打包进 assets 分区
- TTS 音色数据(2.94MB)+ 语音模型共占 assets 6.52MB(分区 8MB)
- 首次使用需在 `menuconfig` 中配置 OneNET 凭证与 WiFi

## 📜 许可证

本项目基于 XiaoZhi(小智)开源固件,遵循其开源许可证。
