#ifndef __TIMER_CONTROLLER_H__
#define __TIMER_CONTROLLER_H__

#include <esp_timer.h>

#include <mutex>
#include <string>

#include "application.h"
#include "assets/lang_config.h"
#include "mcp_server.h"

#include <esp_log.h>

#define TIMER_TAG "TimerController"


class TimerController {
private:
    struct ActiveTimer {
        esp_timer_handle_t handle = nullptr;
        int64_t end_time_us = 0;
        std::string message;
    };

    std::mutex mutex_;
    ActiveTimer active_;

    static void OnTimerExpired(void* arg) {
        auto* self = static_cast<TimerController*>(arg);
        self->HandleExpired();
    }

    void HandleExpired() {
        std::string message;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (active_.handle == nullptr) {
                return;
            }
            esp_timer_stop(active_.handle);
            esp_timer_delete(active_.handle);
            active_.handle = nullptr;
            message = active_.message;
        }
        // Runs in the esp_timer task; schedule the UI mutation on the main task
        ESP_LOGW(TIMER_TAG, "Timer expired, alerting: %s", message.c_str());
        Application::GetInstance().Schedule([message]() {
            Application::GetInstance().Alert("时间到", message.c_str(), "happy", Lang::Sounds::OGG_DRINK_WATER);
        });
    }

public:
    TimerController() {
        auto& mcp_server = McpServer::GetInstance();

        mcp_server.AddTool("self.timer.set",
            "Set a countdown timer in seconds; when it expires the device shows an alert and plays a reminder sound",
            PropertyList({
                Property("seconds", kPropertyTypeInteger, 1, 86400),
                Property("message", kPropertyTypeString, std::string("时间到了")),
            }),
            [this](const PropertyList& properties) -> ReturnValue {
                int seconds = properties["seconds"].value<int>();
                std::string message = properties["message"].value<std::string>();
                ESP_LOGW(TIMER_TAG, "set called: seconds=%d message=%s", seconds, message.c_str());

                std::lock_guard<std::mutex> lock(mutex_);
                if (active_.handle != nullptr) {
                    esp_timer_stop(active_.handle);
                    esp_timer_delete(active_.handle);
                }

                esp_timer_create_args_t timer_args = {};
                timer_args.callback = &TimerController::OnTimerExpired;
                timer_args.arg = this;
                timer_args.name = "timer_reminder";
                if (esp_timer_create(&timer_args, &active_.handle) != ESP_OK) {
                    active_.handle = nullptr;
                    return std::string("{\"success\": false, \"error\": \"failed to create timer\"}");
                }

                esp_timer_start_once(active_.handle, (uint64_t)seconds * 1000000);
                active_.end_time_us = esp_timer_get_time() + (uint64_t)seconds * 1000000;
                active_.message = message;

                return std::string("{\"success\": true, \"seconds\": ") + std::to_string(seconds) +
                       ", \"message\": \"" + message + "\"}";
            });

        mcp_server.AddTool("self.timer.get_status",
            "Get the remaining time of the active countdown timer, or report that no timer is running",
            PropertyList(),
            [this](const PropertyList& properties) -> ReturnValue {
                std::lock_guard<std::mutex> lock(mutex_);
                if (active_.handle == nullptr) {
                    return std::string("{\"running\": false}");
                }
                int64_t remaining_us = active_.end_time_us - esp_timer_get_time();
                if (remaining_us < 0) {
                    remaining_us = 0;
                }
                return std::string("{\"running\": true, \"remaining_seconds\": ") +
                       std::to_string(remaining_us / 1000000) + ", \"message\": \"" + active_.message + "\"}";
            });

        mcp_server.AddTool("self.timer.cancel",
            "Cancel the active countdown timer if one is running",
            PropertyList(),
            [this](const PropertyList& properties) -> ReturnValue {
                std::lock_guard<std::mutex> lock(mutex_);
                if (active_.handle == nullptr) {
                    return std::string("{\"success\": false, \"error\": \"no active timer\"}");
                }
                esp_timer_stop(active_.handle);
                esp_timer_delete(active_.handle);
                active_.handle = nullptr;
                return std::string("{\"success\": true}");
            });
    }
};


#endif // __TIMER_CONTROLLER_H__
