#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "display/oled_display.h"
#include "system_reset.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "mcp_server.h"
#include "lamp_controller.h"
#include "led/single_led.h"
#include "assets/lang_config.h"
#include <driver/gpio.h>
#include <esp_heap_caps.h>

#include <esp_log.h>
#include <driver/i2c_master.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#ifdef SH1106
#include <esp_lcd_panel_sh1106.h>
#endif

#define TAG "CompactWifiBoard"


class CompactWifiBoard : public WifiBoard {
private:
    i2c_master_bus_handle_t display_i2c_bus_;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;
    Display* display_ = nullptr;

    Button boot_button_;
    Button touch_button_;
    Button volume_up_button_;
    Button volume_down_button_;


    // ============================================================
    // DISPLAY I2C
    // ============================================================

    void InitializeDisplayI2c() {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = DISPLAY_SDA_PIN,
            .scl_io_num = DISPLAY_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };

        ESP_ERROR_CHECK(
            i2c_new_master_bus(
                &bus_config,
                &display_i2c_bus_
            )
        );
    }


    // ============================================================
    // SSD1306 DISPLAY
    // ============================================================

    void InitializeSsd1306Display() {

        esp_lcd_panel_io_i2c_config_t io_config = {
            .dev_addr = 0x3C,
            .scl_speed_hz = 400 * 1000,
            .control_phase_bytes = 1,
            .dc_bit_offset = 6,
            .lcd_cmd_bits = 8,
            .lcd_param_bits = 8,
            .on_color_trans_done = nullptr,
            .user_ctx = nullptr,
            .flags = {
                .dc_low_on_data = 0,
                .disable_control_phase = 0,
            },
        };


        ESP_ERROR_CHECK(
            esp_lcd_new_panel_io_i2c(
                display_i2c_bus_,
                &io_config,
                &panel_io_
            )
        );


        ESP_LOGI(TAG, "Installing SSD1306 driver");


        esp_lcd_panel_dev_config_t panel_config = {};

        panel_config.reset_gpio_num = GPIO_NUM_NC;
        panel_config.bits_per_pixel = 1;


        esp_lcd_panel_ssd1306_config_t ssd1306_config = {
            .height = static_cast<uint8_t>(DISPLAY_HEIGHT),
        };


        panel_config.vendor_config =
            &ssd1306_config;


#ifdef SH1106

        ESP_ERROR_CHECK(
            esp_lcd_new_panel_sh1106(
                panel_io_,
                &panel_config,
                &panel_
            )
        );

#else

        ESP_ERROR_CHECK(
            esp_lcd_new_panel_ssd1306(
                panel_io_,
                &panel_config,
                &panel_
            )
        );

#endif


        ESP_LOGI(TAG, "SSD1306 driver installed");


        ESP_ERROR_CHECK(
            esp_lcd_panel_reset(panel_)
        );


        if (esp_lcd_panel_init(panel_) != ESP_OK) {

            ESP_LOGE(
                TAG,
                "Failed to initialize display"
            );

            display_ = new NoDisplay();
            return;
        }


        ESP_ERROR_CHECK(
            esp_lcd_panel_invert_color(
                panel_,
                false
            )
        );


        ESP_LOGI(
            TAG,
            "Turning display on"
        );


        ESP_ERROR_CHECK(
            esp_lcd_panel_disp_on_off(
                panel_,
                true
            )
        );


        display_ = new OledDisplay(
            panel_io_,
            panel_,
            DISPLAY_WIDTH,
            DISPLAY_HEIGHT,
            DISPLAY_MIRROR_X,
            DISPLAY_MIRROR_Y
        );
    }


    // ============================================================
    // BUTTONS
    // ============================================================

    void InitializeButtons() {

        boot_button_.OnClick([this]() {

            auto& app =
                Application::GetInstance();


            if (app.GetDeviceState() ==
                kDeviceStateStarting) {

                EnterWifiConfigMode();
                return;
            }


            app.ToggleChatState();
        });


        touch_button_.OnPressDown([this]() {

            Application::GetInstance()
                .StartListening();
        });


        touch_button_.OnPressUp([this]() {

            Application::GetInstance()
                .StopListening();
        });


        volume_up_button_.OnClick([this]() {

            auto codec =
                GetAudioCodec();


            auto volume =
                codec->output_volume() + 10;


            if (volume > 100) {
                volume = 100;
            }


            codec->SetOutputVolume(volume);


            GetDisplay()->ShowNotification(
                Lang::Strings::VOLUME +
                std::to_string(volume)
            );
        });


        volume_up_button_.OnLongPress([this]() {

            GetAudioCodec()->SetOutputVolume(100);


            GetDisplay()->ShowNotification(
                Lang::Strings::MAX_VOLUME
            );
        });


        volume_down_button_.OnClick([this]() {

            auto codec =
                GetAudioCodec();


            auto volume =
                codec->output_volume() - 10;


            if (volume < 0) {
                volume = 0;
            }


            codec->SetOutputVolume(volume);


            GetDisplay()->ShowNotification(
                Lang::Strings::VOLUME +
                std::to_string(volume)
            );
        });


        volume_down_button_.OnLongPress([this]() {

            GetAudioCodec()->SetOutputVolume(0);


            GetDisplay()->ShowNotification(
                Lang::Strings::MUTED
            );
        });
    }


    // ============================================================
    // LAMP CONTROLLER
    // ============================================================

    static LampController& GetLampController() {

        /*
         * Your config.h defines:
         *
         *     LAMP_GPIO = GPIO18
         *
         * Therefore this controller directly switches GPIO18.
         */
        static LampController lamp(LAMP_GPIO);

        return lamp;
    }

    
static void InitializeRgbLeds() {
    gpio_config_t io_conf = {};
    io_conf.pin_bit_mask =
        (1ULL << RED_LED_GPIO) |
        (1ULL << YELLOW_LED_GPIO) |
        (1ULL << GREEN_LED_GPIO);
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.intr_type = GPIO_INTR_DISABLE;

    const esp_err_t err = gpio_config(&io_conf);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "RGB LED GPIO initialization failed: %s",
                 esp_err_to_name(err));
        return;
    }

    gpio_set_level(RED_LED_GPIO, 0);
    gpio_set_level(YELLOW_LED_GPIO, 0);
    gpio_set_level(GREEN_LED_GPIO, 0);

    ESP_LOGI(TAG, "RGB LEDs initialized on GPIO8, GPIO9, GPIO10");
}

static bool IsRgbLedAction(const std::string& action) {
    return
        action == "red_on" || action == "red_off" ||
        action == "yellow_on" || action == "yellow_off" ||
        action == "green_on" || action == "green_off" ||
        action == "red_yellow_on" || action == "red_yellow_off" ||
        action == "red_green_on" || action == "red_green_off" ||
        action == "yellow_green_on" || action == "yellow_green_off" ||
        action == "all_on" || action == "all_off";
}

static bool ApplyRgbLedAction(const std::string& action) {
    bool success = true;

    auto set_led = [&success](gpio_num_t pin, bool on) {
        const esp_err_t err = gpio_set_level(pin, on ? 1 : 0);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "GPIO%d control failed: %s",
                     static_cast<int>(pin), esp_err_to_name(err));
            success = false;
        }
    };

    if (action == "red_on") {
        set_led(RED_LED_GPIO, true);
    } else if (action == "red_off") {
        set_led(RED_LED_GPIO, false);
    } else if (action == "yellow_on") {
        set_led(YELLOW_LED_GPIO, true);
    } else if (action == "yellow_off") {
        set_led(YELLOW_LED_GPIO, false);
    } else if (action == "green_on") {
        set_led(GREEN_LED_GPIO, true);
    } else if (action == "green_off") {
        set_led(GREEN_LED_GPIO, false);
    } else if (action == "red_yellow_on") {
        set_led(RED_LED_GPIO, true);
        set_led(YELLOW_LED_GPIO, true);
    } else if (action == "red_yellow_off") {
        set_led(RED_LED_GPIO, false);
        set_led(YELLOW_LED_GPIO, false);
    } else if (action == "red_green_on") {
        set_led(RED_LED_GPIO, true);
        set_led(GREEN_LED_GPIO, true);
    } else if (action == "red_green_off") {
        set_led(RED_LED_GPIO, false);
        set_led(GREEN_LED_GPIO, false);
    } else if (action == "yellow_green_on") {
        set_led(YELLOW_LED_GPIO, true);
        set_led(GREEN_LED_GPIO, true);
    } else if (action == "yellow_green_off") {
        set_led(YELLOW_LED_GPIO, false);
        set_led(GREEN_LED_GPIO, false);
    } else if (action == "all_on") {
        set_led(RED_LED_GPIO, true);
        set_led(YELLOW_LED_GPIO, true);
        set_led(GREEN_LED_GPIO, true);
    } else if (action == "all_off") {
        set_led(RED_LED_GPIO, false);
        set_led(YELLOW_LED_GPIO, false);
        set_led(GREEN_LED_GPIO, false);
    } else {
        return false;
    }

    return success;
}

static const char* GetRgbLedResponse(const std::string& action) {
    return action.find("_on") != std::string::npos
        ? "Okay, the selected lights are on."
        : "Okay, the selected lights are off.";
}
    // Register LED controls for the online XiaoZhi assistant.
    void RegisterRgbLedOnlineTool() {
        McpServer::GetInstance().AddTool(
            "self.rgb_leds.set",
            "Control the red, yellow and green LEDs. The lights "
            "value must be red, yellow, green, red_yellow, "
            "red_green, yellow_green, or all. Set on=true to "
            "turn selected lights on or on=false to turn them off. "
            "This tool does not control the existing GPIO18 lamp.",
            PropertyList({
                Property("lights", kPropertyTypeString),
                Property("on", kPropertyTypeBoolean)
            }),
            [](const PropertyList& properties) -> ReturnValue {
                const std::string lights =
                    properties["lights"].value<std::string>();
                const bool on =
                    properties["on"].value<bool>();

                const std::string action =
                    lights + (on ? "_on" : "_off");

                if (!CompactWifiBoard::IsRgbLedAction(action)) {
                    ESP_LOGW(TAG, "Invalid RGB light selection: %s",
                             lights.c_str());
                    return std::string("Invalid light selection");
                }

                if (!CompactWifiBoard::ApplyRgbLedAction(action)) {
                    return std::string(
                        "Failed to control the selected lights");
                }

                ESP_LOGI(TAG, "Online RGB LED tool executed: %s",
                         action.c_str());
                return true;
            }
        );
    }




    // ============================================================
    // OFFLINE COMMAND WORKER
    // ============================================================

#ifdef CONFIG_USE_OFFLINE_COMMANDS

    struct OfflineCommandArgs {
        std::string text;
        std::string action;
    };


    

static void RunOfflineCommand(void* arg) {
    auto* args = static_cast<OfflineCommandArgs*>(arg);
    auto& app = Application::GetInstance();

    ESP_LOGI(TAG, "Running offline command: text=%s action=%s",
             args->text.c_str(), args->action.c_str());

    // Existing LED on GPIO18
    if (args->action == "device_on") {
        GetLampController().TurnOn();
        ESP_LOGI(TAG, "Existing LED -> ON");
        app.SpeakLocalText("Okay, LED is on");
    }
    else if (args->action == "device_off") {
        GetLampController().TurnOff();
        ESP_LOGI(TAG, "Existing LED -> OFF");
        app.SpeakLocalText("Okay, LED is off");
    }

   
    // Independent red, yellow, green LEDs and combinations
    else if (IsRgbLedAction(args->action)) {
        if (!ApplyRgbLedAction(args->action)) {
            ESP_LOGE(TAG, "RGB LED action failed: %s",
                     args->action.c_str());
            app.SpeakLocalText("Sorry, I could not control those lights");
        } else {
            ESP_LOGI(TAG, "RGB LED action completed: %s",
                     args->action.c_str());
            app.SpeakLocalText(GetRgbLedResponse(args->action));
        }
    }


    // Conversational offline replies
    else if (args->action == "say_hello") {
        app.SpeakLocalText("Hello! I'm Eva, your voice assistant.");
    }
    else if (args->action == "how_are_you") {
        app.SpeakLocalText("I'm doing well and ready to help.");
    }
    else if (args->action == "who_are_you") {
        app.SpeakLocalText("I'm Eva, your personal voice assistant.");
    }
    else if (args->action == "good_morning") {
        app.SpeakLocalText("Good morning! Have a great day.");
    }
    else if (args->action == "tell_joke") {
        app.SpeakLocalText(
            "Why did the computer get cold? "
            "Because it left its Windows open!");
    }
    else if (args->action == "what_can_you_do") {
        app.SpeakLocalText(
            "I'm Eva. Offline, I can control three LEDs "
            "and answer some simple questions. "
            "For general questions, I can use my online assistant.");
    }
    else {
        ESP_LOGW(TAG, "Unknown offline command action: %s",
                 args->action.c_str());
    }

    delete args;
    vTaskDelete(nullptr);
}




    // ============================================================
    // REGISTER OFFLINE COMMAND CALLBACK
    // ============================================================

    void RegisterOfflineCommandHandlers() {

        Application::GetInstance()
            .RegisterCommandHandler(
                [](const std::string& text,
                   const std::string& action) {

                    ESP_LOGI(
                        TAG,
                        "Offline command received: %s (%s)",
                        text.c_str(),
                        action.c_str()
                    );


                    auto* args =
                        new OfflineCommandArgs{
                            text,
                            action
                        };


                    /*
                     * Do not execute TTS directly in the main
                     * application task.
                     *
                     * Run the local command in a worker task.
                     */
                    BaseType_t result =
                        xTaskCreate(
                            RunOfflineCommand,
                            "offline_cmd",
                            4096,
                            args,
                            5,
                            nullptr     
                        );


                    if (result != pdPASS) {

                        ESP_LOGE(
        TAG,
        "Failed to create offline command task. Free internal heap: %u bytes; largest block: %u bytes",
        static_cast<unsigned int>(
            heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT)),
        static_cast<unsigned int>(
            heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT))
    );

    delete args;
                    }
                }
            );
    }

#endif


    // ============================================================
    // TOOLS
    // ============================================================

    // Initialize the existing GPIO18 lamp.

    // ============================================================
    // TOOLS
    // ============================================================

    
    void InitializeTools() {
        // Keep the existing GPIO18 lamp working.
        GetLampController();

        // Initialize red, yellow and green LEDs.
        InitializeRgbLeds();

        // Register the LED control tool for the online assistant.
        RegisterRgbLedOnlineTool();

#ifdef CONFIG_USE_OFFLINE_COMMANDS
        ESP_LOGI(TAG, "Registering offline command handlers");
        RegisterOfflineCommandHandlers();
#else
        ESP_LOGI(TAG, "Offline command support is disabled in Kconfig");
#endif
    }




public:

    // ============================================================
    // CONSTRUCTOR
    // ============================================================

    CompactWifiBoard()
        :
        boot_button_(BOOT_BUTTON_GPIO),
        touch_button_(TOUCH_BUTTON_GPIO),
        volume_up_button_(VOLUME_UP_BUTTON_GPIO),
        volume_down_button_(VOLUME_DOWN_BUTTON_GPIO) {

        InitializeDisplayI2c();

        InitializeSsd1306Display();

        InitializeButtons();

        InitializeTools();
    }


    // ============================================================
    // BUILT-IN LED
    // ============================================================

    virtual Led* GetLed() override {

        static SingleLed led(
            BUILTIN_LED_GPIO
        );

        return &led;
    }


    // ============================================================
    // AUDIO CODEC
    // ============================================================

    virtual AudioCodec* GetAudioCodec() override {

#ifdef AUDIO_I2S_METHOD_SIMPLEX

        static NoAudioCodecSimplex audio_codec(
            AUDIO_INPUT_SAMPLE_RATE,
            AUDIO_OUTPUT_SAMPLE_RATE,

            AUDIO_I2S_SPK_GPIO_BCLK,
            AUDIO_I2S_SPK_GPIO_LRCK,
            AUDIO_I2S_SPK_GPIO_DOUT,

            AUDIO_I2S_MIC_GPIO_SCK,
            AUDIO_I2S_MIC_GPIO_WS,
            AUDIO_I2S_MIC_GPIO_DIN
        );

#else

        static NoAudioCodecDuplex audio_codec(
            AUDIO_INPUT_SAMPLE_RATE,
            AUDIO_OUTPUT_SAMPLE_RATE,

            AUDIO_I2S_GPIO_BCLK,
            AUDIO_I2S_GPIO_WS,
            AUDIO_I2S_GPIO_DOUT,
            AUDIO_I2S_GPIO_DIN
        );

#endif

        return &audio_codec;
    }


    // ============================================================
    // DISPLAY
    // ============================================================

    virtual Display* GetDisplay() override {
        return display_;
    }
};


// ================================================================
// BOARD REGISTRATION
// ================================================================

DECLARE_BOARD(CompactWifiBoard);