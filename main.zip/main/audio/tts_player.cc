#include "tts_player.h"

#include "application.h"
#include "assets.h"
#include "audio_service.h"

#include <esp_log.h>
#include <esp_tts.h>
#include <esp_tts_voice.h>
#include <esp_tts_voice_xiaole.h>

#include <vector>

#define TAG "TtsPlayer"

TtsPlayer::~TtsPlayer() {
    if (tts_handle_ != nullptr) {
        esp_tts_destroy(tts_handle_);
        tts_handle_ = nullptr;
    }
}

TtsPlayer& TtsPlayer::GetInstance() {
    static TtsPlayer instance;
    return instance;
}

bool TtsPlayer::Initialize() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (initialized_) {
        return true;
    }

    auto& assets = Assets::GetInstance();
    void* ptr = nullptr;
    size_t size = 0;
    if (!assets.GetAssetData("esp_tts_voice_data_xiaole.dat", ptr, size)) {
        ESP_LOGE(TAG, "Failed to read TTS voice data from assets partition");
        return false;
    }

    // The voice data pointer must stay valid for the lifetime of the voice
    // set; the assets partition stays mapped, so passing the mmap pointer is
    // safe.
    auto* voice = esp_tts_voice_set_init(&esp_tts_voice_xiaole, ptr);
    if (voice == nullptr) {
        ESP_LOGE(TAG, "Failed to initialize TTS voice set");
        return false;
    }

    tts_handle_ = esp_tts_create(voice);
    if (tts_handle_ == nullptr) {
        ESP_LOGE(TAG, "Failed to create TTS instance");
        esp_tts_voice_set_free(voice);
        return false;
    }

    initialized_ = true;
    ESP_LOGI(TAG, "TTS initialized (voice: xiaole)");
    return true;
}

void TtsPlayer::Speak(const std::string& text) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!Initialize()) {
        return;
    }
    if (text.empty() || tts_handle_ == nullptr) {
        return;
    }

    if (!esp_tts_parse_chinese(tts_handle_, text.c_str())) {
        ESP_LOGW(TAG, "Failed to parse text for TTS: %s", text.c_str());
        return;
    }

    // Synthesize in one pass and play the PCM (16 kHz mono 16-bit).
    std::vector<int16_t> pcm;
    pcm.reserve(16000 * 8);  // Up to 8 seconds of speech
    int len = 0;
    while (true) {
        short* data = esp_tts_stream_play(tts_handle_, &len, 4);
        if (data == nullptr || len <= 0) {
            break;
        }
        pcm.insert(pcm.end(), data, data + len);
    }

    if (!pcm.empty()) {
        ESP_LOGI(TAG, "Playing TTS audio: %d samples (%d ms)", (int)pcm.size(),
                 (int)(pcm.size() * 1000 / 16000));
        auto& audio_service = Application::GetInstance().GetAudioService();
        audio_service.PlayPcm(std::move(pcm), 16000);
    }
    esp_tts_stream_reset(tts_handle_);
}
