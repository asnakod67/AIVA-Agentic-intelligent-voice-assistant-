#include "custom_wake_word.h"

#include "audio_service.h"
#include "system_info.h"
#include "assets.h"

#include <esp_log.h>
#include <esp_timer.h>
#include <esp_heap_caps.h>

#include <esp_mn_iface.h>
#include <esp_mn_models.h>
#include <esp_mn_speech_commands.h>

#include <cJSON.h>

#include <algorithm>
#include <cassert>
#include <cstring>
#include <sstream>

#define TAG "CustomWakeWord"


CustomWakeWord::CustomWakeWord()
    : wake_word_opus_() {
}


CustomWakeWord::~CustomWakeWord() {
    running_ = false;

    if (multinet_model_data_ != nullptr && multinet_ != nullptr) {
        multinet_->destroy(multinet_model_data_);
        multinet_model_data_ = nullptr;
    }

    if (wake_word_encode_task_stack_ != nullptr) {
        heap_caps_free(wake_word_encode_task_stack_);
        wake_word_encode_task_stack_ = nullptr;
    }

    if (wake_word_encode_task_buffer_ != nullptr) {
        heap_caps_free(wake_word_encode_task_buffer_);
        wake_word_encode_task_buffer_ = nullptr;
    }

    if (owns_models_ && models_ != nullptr) {
        esp_srmodel_deinit(models_);
        models_ = nullptr;
    }
}


void CustomWakeWord::ParseWakenetModelConfig() {
    auto& assets = Assets::GetInstance();

    void* ptr = nullptr;
    size_t size = 0;

    if (!assets.GetAssetData("index.json", ptr, size)) {
        ESP_LOGW(TAG, "index.json not found");
        return;
    }

    cJSON* root = cJSON_ParseWithLength(
        static_cast<char*>(ptr),
        size
    );

    if (root == nullptr) {
        ESP_LOGW(TAG, "Failed to parse index.json");
        return;
    }

    cJSON* multinet_model =
        cJSON_GetObjectItem(root, "multinet_model");

    if (cJSON_IsObject(multinet_model)) {

        cJSON* language =
            cJSON_GetObjectItem(multinet_model, "language");

        cJSON* duration =
            cJSON_GetObjectItem(multinet_model, "duration");

        cJSON* threshold =
            cJSON_GetObjectItem(multinet_model, "threshold");

        cJSON* commands =
            cJSON_GetObjectItem(multinet_model, "commands");


        if (cJSON_IsString(language)) {
            language_ = language->valuestring;
        }

        if (cJSON_IsNumber(duration)) {
            duration_ = duration->valueint;
        }

        if (cJSON_IsNumber(threshold)) {
            threshold_ = threshold->valuedouble;
        }


        if (cJSON_IsArray(commands)) {

            for (int i = 0;
                 i < cJSON_GetArraySize(commands);
                 ++i) {

                cJSON* command =
                    cJSON_GetArrayItem(commands, i);

                if (!cJSON_IsObject(command)) {
                    continue;
                }

                cJSON* command_name =
                    cJSON_GetObjectItem(command, "command");

                cJSON* text =
                    cJSON_GetObjectItem(command, "text");

                cJSON* action =
                    cJSON_GetObjectItem(command, "action");


                if (cJSON_IsString(command_name) &&
                    cJSON_IsString(text) &&
                    cJSON_IsString(action)) {

                    commands_.push_back({
                        command_name->valuestring,
                        text->valuestring,
                        action->valuestring
                    });

                    ESP_LOGI(
                        TAG,
                        "Asset command: command=%s text=%s action=%s",
                        command_name->valuestring,
                        text->valuestring,
                        action->valuestring
                    );
                }
            }
        }
    }

    cJSON_Delete(root);
}


bool CustomWakeWord::Initialize(
    AudioCodec* codec,
    srmodel_list_t* models_list) {

    codec_ = codec;
    commands_.clear();

    language_ = "en";
    duration_ = 3000;
    threshold_ = 0.20f;


    /*
     * ------------------------------------------------------------
     * CUSTOM WAKE WORD MODE
     * ------------------------------------------------------------
     *
     * Our target configuration is:
     *
     *     English MultiNet
     *     Wake word = Eva
     *     Offline commands = optional
     *
     * Do not depend on index.json for this configuration.
     */
#ifdef CONFIG_USE_CUSTOM_WAKE_WORD

    ESP_LOGI(TAG, "Initializing custom wake-word mode");

    /*
     * The XiaoZhi configuration already selects the English
     * MultiNet model. Explicitly use English here so the selected
     * model is searched correctly.
     */
    language_ = "en";

    /*
     * CONFIG_CUSTOM_WAKE_WORD_THRESHOLD is expressed as a
     * percentage in Kconfig.
     *
     * Example:
     *     20 -> 0.20
     */
#ifdef CONFIG_CUSTOM_WAKE_WORD_THRESHOLD
    threshold_ =
        static_cast<float>(CONFIG_CUSTOM_WAKE_WORD_THRESHOLD) / 100.0f;
#endif


    /*
     * Add the configured wake word as command #1.
     */
#ifdef CONFIG_CUSTOM_WAKE_WORD

    commands_.push_back({
        CONFIG_CUSTOM_WAKE_WORD,
#ifdef CONFIG_CUSTOM_WAKE_WORD_DISPLAY
        CONFIG_CUSTOM_WAKE_WORD_DISPLAY,
#else
        CONFIG_CUSTOM_WAKE_WORD,
#endif
        "wake"
    });

    ESP_LOGI(
        TAG,
        "Wake word: %s",
        CONFIG_CUSTOM_WAKE_WORD
    );

#endif


    /*
     * ------------------------------------------------------------
     * OFFLINE COMMANDS
     * ------------------------------------------------------------
     *
     * Kconfig format:
     *
     * command,text,action;command,text,action;...
     *
     * Example:
     *
     * turn on led,Turn on LED,device_on;
     * turn off led,Turn off LED,device_off
     */
#ifdef CONFIG_USE_OFFLINE_COMMANDS

#ifdef CONFIG_OFFLINE_COMMANDS

    std::string offline_commands =
        CONFIG_OFFLINE_COMMANDS;

    std::stringstream ss(offline_commands);
    std::string item;

    while (std::getline(ss, item, ';')) {

        if (item.empty()) {
            continue;
        }

        std::stringstream item_stream(item);

        std::string command;
        std::string text;
        std::string action;

        if (!std::getline(item_stream, command, ',')) {
            continue;
        }

        if (!std::getline(item_stream, text, ',')) {
            continue;
        }

        if (!std::getline(item_stream, action, ',')) {
            continue;
        }

        /*
         * Remove leading/trailing spaces.
         */
        auto trim = [](std::string& value) {

            while (!value.empty() &&
                   (value.front() == ' ' ||
                    value.front() == '\t')) {

                value.erase(value.begin());
            }

            while (!value.empty() &&
                   (value.back() == ' ' ||
                    value.back() == '\t')) {

                value.pop_back();
            }
        };

        trim(command);
        trim(text);
        trim(action);

        if (command.empty() ||
            text.empty() ||
            action.empty()) {

            continue;
        }

        commands_.push_back({
            command,
            text,
            action
        });

        ESP_LOGI(
            TAG,
            "Offline command: %s | %s | %s",
            command.c_str(),
            text.c_str(),
            action.c_str()
        );
    }

#endif

#endif


    /*
     * ------------------------------------------------------------
     * MODEL LIST
     * ------------------------------------------------------------
     */

    if (models_list != nullptr) {

        /*
         * AFE normally supplies the already initialized model list.
         */
        models_ = models_list;
        owns_models_ = false;

    } else {

        /*
         * Fallback for direct initialization.
         */
        models_ = esp_srmodel_init("model");
        owns_models_ = models_ != nullptr;
    }


#else

    /*
     * ------------------------------------------------------------
     * ORIGINAL / NON-CUSTOM MODE
     * ------------------------------------------------------------
     */

    if (models_list == nullptr) {

        models_ = esp_srmodel_init("model");
        owns_models_ = models_ != nullptr;

    } else {

        models_ = models_list;
        owns_models_ = false;

        ParseWakenetModelConfig();
    }

#endif


    /*
     * Verify model list.
     */
    if (models_ == nullptr ||
        models_->num <= 0) {

        ESP_LOGE(
            TAG,
            "Speech recognition model list is invalid"
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Searching MultiNet model, language=%s",
        language_.c_str()
    );


    /*
     * Find the MultiNet model for the requested language.
     */
    mn_name_ =
        esp_srmodel_filter(
            models_,
            ESP_MN_PREFIX,
            language_.c_str()
        );


    /*
     * Fallback if the requested language model cannot be found.
     */
    if (mn_name_ == nullptr) {

        ESP_LOGW(
            TAG,
            "MultiNet model for language '%s' not found",
            language_.c_str()
        );

        mn_name_ =
            esp_srmodel_filter(
                models_,
                ESP_MN_PREFIX,
                nullptr
            );
    }


    if (mn_name_ == nullptr) {

        ESP_LOGE(
            TAG,
            "No MultiNet model found"
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Using MultiNet model: %s",
        mn_name_
    );


    /*
     * Get MultiNet interface.
     */
    multinet_ =
        esp_mn_handle_from_name(mn_name_);


    if (multinet_ == nullptr) {

        ESP_LOGE(
            TAG,
            "esp_mn_handle_from_name() failed"
        );

        return false;
    }


    /*
     * Create model runtime data.
     */
    multinet_model_data_ =
        multinet_->create(
            mn_name_,
            duration_
        );


    if (multinet_model_data_ == nullptr) {

        ESP_LOGE(
            TAG,
            "Failed to create MultiNet model data"
        );

        return false;
    }


    /*
     * Detection threshold.
     */
    multinet_->set_det_threshold(
        multinet_model_data_,
        threshold_
    );


    /*
     * Allocate enough room for at least one MultiNet chunk.
     */
    const size_t chunk_size =
        multinet_->get_samp_chunksize(
            multinet_model_data_
        );


    if (chunk_size == 0) {

        ESP_LOGE(
            TAG,
            "MultiNet chunk size is zero"
        );

        return false;
    }


    input_buffer_.reserve(chunk_size * 2);


    /*
     * ------------------------------------------------------------
     * REGISTER SPEECH COMMANDS
     * ------------------------------------------------------------
     */

    esp_mn_commands_clear();


    int command_id = 1;

    for (const auto& command : commands_) {

        if (command.command.empty()) {
            continue;
        }

        esp_mn_commands_add(
            command_id,
            command.command.c_str()
        );

        ESP_LOGI(
            TAG,
            "Register command #%d: %s",
            command_id,
            command.command.c_str()
        );

        ++command_id;
    }


    if (command_id == 1) {

        ESP_LOGE(
            TAG,
            "No MultiNet commands registered"
        );

        return false;
    }


    esp_mn_commands_update();


    /*
     * Print active command list to serial log.
     */
    multinet_->print_active_speech_commands(
        multinet_model_data_
    );


    /*
     * ------------------------------------------------------------
     * WAKE WORD AUDIO CACHE
     * ------------------------------------------------------------
     */

#if CONFIG_SEND_WAKE_WORD_DATA

    /*
     * Keep the original 2-second, 16-kHz PCM cache.
     */
    constexpr size_t WAKE_AUDIO_CACHE_SAMPLES =
        16000 * 2;

    if (!wake_word_audio_cache_.Initialize(
            WAKE_AUDIO_CACHE_SAMPLES)) {

        ESP_LOGW(
            TAG,
            "Wake-word audio cache allocation failed"
        );
    }

#endif


    ESP_LOGI(
        TAG,
        "CustomWakeWord initialized successfully"
    );

    ESP_LOGI(
        TAG,
        "Language: %s",
        language_.c_str()
    );

    ESP_LOGI(
        TAG,
        "Threshold: %.3f",
        threshold_
    );

    ESP_LOGI(
        TAG,
        "Duration: %d ms",
        duration_
    );

    ESP_LOGI(
        TAG,
        "Total commands: %d",
        static_cast<int>(commands_.size())
    );


    return true;
}


void CustomWakeWord::OnWakeWordDetected(
    std::function<void(const std::string& wake_word)> callback) {

    wake_word_detected_callback_ =
        std::move(callback);
}


void CustomWakeWord::OnCommandDetected(
    std::function<void(
        const std::string& text,
        const std::string& action)> callback) {

    command_detected_callback_ =
        std::move(callback);
}


void CustomWakeWord::Start() {

    running_ = true;

    ESP_LOGD(
        TAG,
        "MultiNet detector started"
    );
}


void CustomWakeWord::Stop() {

    running_ = false;

    std::lock_guard<std::mutex> lock(
        input_buffer_mutex_
    );

    input_buffer_.clear();

    ESP_LOGD(
        TAG,
        "MultiNet detector stopped"
    );
}


void CustomWakeWord::Feed(
    const std::vector<int16_t>& data) {

    if (data.empty()) {
        return;
    }

    FeedSamples(
        data.data(),
        data.size(),
        false
    );
}


void CustomWakeWord::FeedMono(
    const int16_t* data,
    size_t samples) {

    FeedSamples(
        data,
        samples,
        true
    );
}


void CustomWakeWord::FeedSamples(
    const int16_t* data,
    size_t samples,
    bool mono) {

    if (multinet_model_data_ == nullptr ||
        multinet_ == nullptr ||
        data == nullptr ||
        samples == 0) {

        return;
    }


    std::lock_guard<std::mutex> lock(
        input_buffer_mutex_
    );


    if (!running_) {
        return;
    }


    /*
     * ------------------------------------------------------------
     * INPUT FORMAT
     * ------------------------------------------------------------
     *
     * FeedMono():
     *     Already mono.
     *
     * Feed():
     *     May contain multiple channels depending on codec.
     */
    if (!mono &&
        codec_ != nullptr &&
        codec_->input_channels() > 1) {

        const size_t channels =
            codec_->input_channels();

        for (size_t i = 0;
             i + channels <= samples;
             i += channels) {

            input_buffer_.push_back(
                data[i]
            );
        }

    } else {

        input_buffer_.insert(
            input_buffer_.end(),
            data,
            data + samples
        );
    }


    const size_t chunk_size =
        multinet_->get_samp_chunksize(
            multinet_model_data_
        );


    if (chunk_size == 0) {
        return;
    }


    /*
     * Process complete MultiNet chunks.
     */
    while (input_buffer_.size() >= chunk_size) {

#if CONFIG_SEND_WAKE_WORD_DATA

        wake_word_audio_cache_.Store(
            input_buffer_.data(),
            chunk_size
        );

#endif


        esp_mn_state_t state =
            multinet_->detect(
                multinet_model_data_,
                input_buffer_.data()
            );


        if (state == ESP_MN_STATE_DETECTED) {

            esp_mn_results_t* result =
                multinet_->get_results(
                    multinet_model_data_
                );


            if (result != nullptr) {

                for (int i = 0;
                     i < result->num && running_;
                     ++i) {

                    const int detected_id =
                        result->command_id[i];


                    if (detected_id < 1 ||
                        detected_id >
                            static_cast<int>(
                                commands_.size())) {

                        ESP_LOGW(
                            TAG,
                            "Invalid command id: %d",
                            detected_id
                        );

                        continue;
                    }


                    auto& command =
                        commands_[detected_id - 1];


                    const float probability =
                        result->prob[i];


                    ESP_LOGI(
                        TAG,
                        "Detected: id=%d command=%s text=%s action=%s probability=%.3f",
                        detected_id,
                        command.command.c_str(),
                        command.text.c_str(),
                        command.action.c_str(),
                        probability
                    );


                    /*
                     * ------------------------------------------------
                     * WAKE WORD
                     * ------------------------------------------------
                     */
                    if (command.action == "wake") {

                        last_detected_wake_word_ =
                            command.text;


                        /*
                         * Preserve the original XiaoZhi behavior:
                         * after recognizing the wake word, the current
                         * MultiNet recognition session ends.
                         *
                         * The Application layer will handle the
                         * transition into online listening.
                         */
                        running_ = false;
                        input_buffer_.clear();





                        if (wake_word_detected_callback_) {

                            wake_word_detected_callback_(
                                last_detected_wake_word_
                            );
                        }


                    /*
                     * ------------------------------------------------
                     * OFFLINE COMMAND
                     * ------------------------------------------------
                     */
                    } else {

                        if (!command_detected_callback_) {
                            continue;
                        }


                        /*
                         * Prevent one physical utterance from creating
                         * many callbacks.
                         */
                        const uint64_t now_us =
                            esp_timer_get_time();


                        const bool different_command =
                            command.text !=
                            last_detected_command_;


                        const bool debounce_expired =
                            (now_us -
                             last_command_detected_us_) >=
                            2000000ULL;


                        if (different_command ||
                            debounce_expired) {

                            last_detected_command_ =
                                command.text;

                            last_command_detected_us_ =
                                now_us;


                            ESP_LOGI(
                                TAG,
                                "Offline command callback: %s (%s)",
                                command.text.c_str(),
                                command.action.c_str()
                            );


                            command_detected_callback_(
                                command.text,
                                command.action
                            );
                        }
                    }
                }
            }


            /*
             * Reset MultiNet detection state after a detection.
             */
            multinet_->clean(
                multinet_model_data_
            );


        } else if (state == ESP_MN_STATE_TIMEOUT) {

            ESP_LOGD(
                TAG,
                "MultiNet detection timeout"
            );


            multinet_->clean(
                multinet_model_data_
            );
        }


        /*
         * Stop() or wake-word detection may have changed running_.
         */
        if (!running_) {
            break;
        }


        /*
         * Remove the chunk we just processed.
         */
        input_buffer_.erase(
            input_buffer_.begin(),
            input_buffer_.begin() + chunk_size
        );
    }
}


size_t CustomWakeWord::GetFeedSize() {

    if (multinet_model_data_ == nullptr ||
        multinet_ == nullptr) {

        return 0;
    }

    return multinet_->get_samp_chunksize(
        multinet_model_data_
    );
}


void CustomWakeWord::EncodeWakeWordData() {

#if !CONFIG_SEND_WAKE_WORD_DATA

    return;

#else

    const size_t stack_size =
        4096 * 7;


    wake_word_opus_.clear();


    if (wake_word_encode_task_stack_ == nullptr) {

        wake_word_encode_task_stack_ =
            static_cast<StackType_t*>(
                heap_caps_malloc(
                    stack_size,
                    MALLOC_CAP_SPIRAM
                )
            );

        assert(
            wake_word_encode_task_stack_ != nullptr
        );
    }


    if (wake_word_encode_task_buffer_ == nullptr) {

        wake_word_encode_task_buffer_ =
            static_cast<StaticTask_t*>(
                heap_caps_malloc(
                    sizeof(StaticTask_t),
                    MALLOC_CAP_INTERNAL
                )
            );

        assert(
            wake_word_encode_task_buffer_ != nullptr
        );
    }


    wake_word_encode_task_ =
        xTaskCreateStatic(
            [](void* arg) {

                auto* this_ =
                    static_cast<CustomWakeWord*>(arg);


                const auto start_time =
                    esp_timer_get_time();


                /*
                 * Create Opus encoder.
                 */
                esp_opus_enc_config_t opus_enc_cfg =
                    AS_OPUS_ENC_CONFIG();


                void* encoder_handle =
                    nullptr;


                esp_audio_err_t ret =
                    esp_opus_enc_open(
                        &opus_enc_cfg,
                        sizeof(esp_opus_enc_config_t),
                        &encoder_handle
                    );


                if (encoder_handle == nullptr) {

                    ESP_LOGE(
                        TAG,
                        "Failed to create Opus encoder, error=%d",
                        ret
                    );


                    this_->wake_word_audio_cache_.Clear();


                    std::lock_guard<std::mutex> lock(
                        this_->wake_word_mutex_
                    );


                    this_->wake_word_opus_.push_back(
                        std::vector<uint8_t>()
                    );


                    this_->wake_word_cv_.notify_all();


                    vTaskDelete(nullptr);
                    return;
                }


                int frame_size = 0;
                int outbuf_size = 0;


                esp_opus_enc_get_frame_size(
                    encoder_handle,
                    &frame_size,
                    &outbuf_size
                );


                frame_size =
                    frame_size /
                    static_cast<int>(sizeof(int16_t));


                if (frame_size <= 0 ||
                    outbuf_size <= 0) {

                    ESP_LOGE(
                        TAG,
                        "Invalid Opus encoder frame information"
                    );

                    this_->wake_word_audio_cache_.Clear();

                    esp_opus_enc_close(
                        encoder_handle
                    );

                    std::lock_guard<std::mutex> lock(
                        this_->wake_word_mutex_
                    );

                    this_->wake_word_opus_.push_back(
                        std::vector<uint8_t>()
                    );

                    this_->wake_word_cv_.notify_all();

                    vTaskDelete(nullptr);
                    return;
                }


                std::vector<int16_t> in_buffer(
                    frame_size
                );


                esp_audio_enc_in_frame_t in = {};
                esp_audio_enc_out_frame_t out = {};


                const size_t cached_samples =
                    this_->wake_word_audio_cache_.Size();


                int packets = 0;


                for (size_t offset = 0;
                     offset +
                         static_cast<size_t>(frame_size)
                         <= cached_samples;
                     offset += frame_size) {


                    const size_t samples_read =
                        this_->wake_word_audio_cache_.Read(
                            offset,
                            in_buffer.data(),
                            frame_size
                        );


                    if (samples_read !=
                        static_cast<size_t>(frame_size)) {

                        break;
                    }


                    std::vector<uint8_t> opus_buffer(
                        outbuf_size
                    );


                    in.buffer =
                        reinterpret_cast<uint8_t*>(
                            in_buffer.data()
                        );

                    in.len =
                        frame_size *
                        sizeof(int16_t);


                    out.buffer =
                        opus_buffer.data();

                    out.len =
                        outbuf_size;

                    out.encoded_bytes =
                        0;


                    ret =
                        esp_opus_enc_process(
                            encoder_handle,
                            &in,
                            &out
                        );


                    if (ret == ESP_AUDIO_ERR_OK) {

                        std::lock_guard<std::mutex> lock(
                            this_->wake_word_mutex_
                        );


                        this_->wake_word_opus_.emplace_back(
                            opus_buffer.data(),
                            opus_buffer.data() +
                                out.encoded_bytes
                        );


                        this_->wake_word_cv_.notify_all();


                        ++packets;

                    } else {

                        ESP_LOGE(
                            TAG,
                            "Opus encoding failed, error=%d",
                            ret
                        );
                    }
                }


                this_->wake_word_audio_cache_.Clear();


                esp_opus_enc_close(
                    encoder_handle
                );


                const auto end_time =
                    esp_timer_get_time();


                ESP_LOGI(
                    TAG,
                    "Wake-word Opus encoding finished: %d packets, %ld ms",
                    packets,
                    static_cast<long>(
                        (end_time - start_time) / 1000
                    )
                );


                /*
                 * Empty packet marks end-of-stream.
                 */
                {
                    std::lock_guard<std::mutex> lock(
                        this_->wake_word_mutex_
                    );


                    this_->wake_word_opus_.push_back(
                        std::vector<uint8_t>()
                    );


                    this_->wake_word_cv_.notify_all();
                }


                vTaskDelete(nullptr);
            },

            "encode_wake_word",
            stack_size,
            this,
            2,

            wake_word_encode_task_stack_,
            wake_word_encode_task_buffer_
        );

#endif
}


bool CustomWakeWord::GetWakeWordOpus(
    std::vector<uint8_t>& opus) {

    std::unique_lock<std::mutex> lock(
        wake_word_mutex_
    );


    wake_word_cv_.wait(
        lock,
        [this]() {
            return !wake_word_opus_.empty();
        }
    );


    opus.swap(
        wake_word_opus_.front()
    );


    wake_word_opus_.pop_front();


    return !opus.empty();
}