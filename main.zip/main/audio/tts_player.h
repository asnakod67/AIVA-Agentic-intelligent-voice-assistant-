#ifndef TTS_PLAYER_H
#define TTS_PLAYER_H

#include <string>
#include <mutex>

typedef void* esp_tts_handle_t;

class TtsPlayer {
public:
    static TtsPlayer& GetInstance();

    // Lazily loads the voice data from the assets partition. Returns false if
    // the voice data or the TTS engine is unavailable.
    bool Initialize();
    // Synthesizes the text (16 kHz mono 16-bit PCM) and plays it through the
    // audio service. Blocking; must not be called from the main task.
    void Speak(const std::string& text);

private:
    TtsPlayer() = default;
    ~TtsPlayer();

    bool initialized_ = false;
    esp_tts_handle_t tts_handle_ = nullptr;
    std::mutex mutex_;
};

#endif
