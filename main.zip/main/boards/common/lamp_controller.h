#ifndef __LAMP_CONTROLLER_H__
#define __LAMP_CONTROLLER_H__

#include "mcp_server.h"

class LampController {
private:
    bool power_ = false;
    gpio_num_t gpio_num_;

public:
    // Turn the lamp ON
    void TurnOn() {
        power_ = true;
        gpio_set_level(gpio_num_, 1);
    }

    // Turn the lamp OFF
    void TurnOff() {
        power_ = false;
        gpio_set_level(gpio_num_, 0);
    }

    // Get current lamp state
    bool IsOn() const {
        return power_;
    }

    LampController(gpio_num_t gpio_num) : gpio_num_(gpio_num) {
        if (gpio_num_ == GPIO_NUM_NC) {
            return;
        }

        gpio_config_t config = {
            .pin_bit_mask = (1ULL << gpio_num_),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };

        ESP_ERROR_CHECK(gpio_config(&config));

        // Start OFF
        TurnOff();

        auto& mcp_server = McpServer::GetInstance();

        // Get lamp state
        mcp_server.AddTool(
            "self.lamp.get_state",
            "Get the power state of the lamp",
            PropertyList(),
            [this](const PropertyList& properties) -> ReturnValue {
                return power_ ? "{\"power\": true}" : "{\"power\": false}";
            });

        // Online/LLM command: turn ON
        mcp_server.AddTool(
            "self.lamp.turn_on",
            "Turn on the lamp",
            PropertyList(),
            [this](const PropertyList& properties) -> ReturnValue {
                TurnOn();
                return true;
            });

        // Online/LLM command: turn OFF
        mcp_server.AddTool(
            "self.lamp.turn_off",
            "Turn off the lamp",
            PropertyList(),
            [this](const PropertyList& properties) -> ReturnValue {
                TurnOff();
                return true;
            });
    }
};

#endif // __LAMP_CONTROLLER_H__